'use strict';

const crypto = require('crypto');
const ccxt = require('ccxt');
const { query, getDbPool } = require('./utils/db');
const { mapWithConcurrency } = require('./utils/concurrency');
const cexTradesService = require('./services/cexTradesService');

const CEX_ENABLED = String(process.env.CEX_ENABLED || '').trim() === '1';
const CEX_EXCHANGES = String(process.env.CEX_EXCHANGES || 'bitmart,gateio,mexc,kucoin')
  .split(',')
  .map((v) => v.trim().toLowerCase())
  .filter(Boolean);

const CEX_TRADE_POLL_INTERVAL_MS = Number(process.env.CEX_TRADE_POLL_INTERVAL_MS || 60_000);
const CEX_OHLCV_REFRESH_MS = Number(process.env.CEX_OHLCV_REFRESH_MS || 30 * 60_000);
const CEX_CONCURRENCY = Number(process.env.CEX_CONCURRENCY || 2);
const CEX_TRADE_LIMIT = Number(process.env.CEX_TRADE_LIMIT || 200);

const exchangeInstances = new Map();
const marketBackoff = new Map(); // key => { failures, nextAllowedAtMs }

const normalizeExchangeId = (value) => (value ? String(value).trim().toLowerCase() : null);

const getExchangeInstance = (exchangeId) => {
  const normalized = normalizeExchangeId(exchangeId);
  if (!normalized) return null;
  if (exchangeInstances.has(normalized)) return exchangeInstances.get(normalized);

  const ExchangeClass = ccxt[normalized];
  if (!ExchangeClass) return null;

  const instance = new ExchangeClass({
    enableRateLimit: true,
  });
  exchangeInstances.set(normalized, instance);
  return instance;
};

const getActiveMarkets = async () => {
  const pool = getDbPool();
  if (!pool) return [];
  const res = await query(
    `
    SELECT exchange_id as "exchangeId", symbol, base_symbol as "baseSymbol", quote_symbol as "quoteSymbol"
    FROM cex_markets
    WHERE active = TRUE
    ORDER BY exchange_id, symbol
    `
  );
  const rows = res.rows || [];
  // Filter to configured exchanges only (safety)
  return rows.filter((row) => CEX_EXCHANGES.includes(String(row.exchangeId).toLowerCase()));
};

const getIngestState = async (exchangeId, symbol) => {
  const res = await query(
    `
    SELECT
      last_trade_ts_ms as "lastTradeTsMs",
      last_trade_id as "lastTradeId",
      last_ohlcv_fetch_at as "lastOhlcvFetchAt",
      last_error as "lastError"
    FROM cex_ingest_state
    WHERE exchange_id = $1 AND symbol = $2
    `,
    [exchangeId, symbol]
  );
  return res.rows?.[0] || null;
};

const setIngestState = async ({
  exchangeId,
  symbol,
  lastTradeTsMs,
  lastTradeId,
  lastOhlcvFetchAt,
  lastError,
}) => {
  await query(
    `
    INSERT INTO cex_ingest_state (
      exchange_id,
      symbol,
      last_trade_ts_ms,
      last_trade_id,
      last_ohlcv_fetch_at,
      last_error,
      updated_at
    )
    VALUES ($1, $2, $3, $4, $5, $6, NOW())
    ON CONFLICT (exchange_id, symbol) DO UPDATE
    SET last_trade_ts_ms = COALESCE(EXCLUDED.last_trade_ts_ms, cex_ingest_state.last_trade_ts_ms),
        last_trade_id = COALESCE(EXCLUDED.last_trade_id, cex_ingest_state.last_trade_id),
        last_ohlcv_fetch_at = COALESCE(EXCLUDED.last_ohlcv_fetch_at, cex_ingest_state.last_ohlcv_fetch_at),
        last_error = EXCLUDED.last_error,
        updated_at = NOW()
    `,
    [
      exchangeId,
      symbol,
      lastTradeTsMs ?? null,
      lastTradeId ?? null,
      lastOhlcvFetchAt ?? null,
      lastError ?? null,
    ]
  );
};

const bumpBackoff = (key) => {
  const now = Date.now();
  const current = marketBackoff.get(key) || { failures: 0, nextAllowedAtMs: 0 };
  const failures = Math.min(10, current.failures + 1);
  const delayMs = Math.min(10 * 60_000, 15_000 * 2 ** (failures - 1)); // 15s, 30s, 60s... max 10m
  marketBackoff.set(key, { failures, nextAllowedAtMs: now + delayMs });
  return delayMs;
};

const clearBackoff = (key) => {
  marketBackoff.delete(key);
};

const backoffAllows = (key) => {
  const state = marketBackoff.get(key);
  if (!state) return true;
  return Date.now() >= Number(state.nextAllowedAtMs || 0);
};

const toTimestamptz = (ms) => {
  const value = Number(ms);
  if (!Number.isFinite(value) || value <= 0) return null;
  return new Date(value);
};

const deriveTradeId = (trade) => {
  if (trade?.id) return String(trade.id);
  const ts = Number(trade?.timestamp || 0);
  if (!Number.isFinite(ts) || ts <= 0) return null;

  // Some exchanges (e.g. BitMart) omit ids; derive a stable identifier.
  const parts = [
    String(ts),
    String(trade?.side || ''),
    trade?.price != null ? String(trade.price) : '',
    trade?.amount != null ? String(trade.amount) : '',
    trade?.cost != null ? String(trade.cost) : '',
  ];

  const hash = crypto.createHash('sha1').update(parts.join('|')).digest('hex');
  return `${ts}-${hash}`;
};

const insertTrades = async (exchangeId, symbol, trades) => {
  if (!Array.isArray(trades) || trades.length === 0) return 0;
  const values = [];
  const placeholders = [];
  let idx = 1;

  for (const trade of trades) {
    const tradeId = deriveTradeId(trade);
    const ts = toTimestamptz(trade.timestamp);
    if (!tradeId || !ts) continue;

    const side = trade.side ? String(trade.side) : null;
    const price = trade.price ?? null;
    const amount = trade.amount ?? null;
    const cost = trade.cost ?? (price != null && amount != null ? Number(price) * Number(amount) : null);

    let feeQuote = null;
    if (trade.fee && trade.fee.cost != null) {
      feeQuote = trade.fee.cost;
    }

    placeholders.push(
      `($${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++})`
    );
    values.push(
      exchangeId,
      symbol,
      tradeId,
      ts,
      side,
      price,
      amount,
      cost,
      feeQuote,
      trade
    );
  }

  if (!placeholders.length) return 0;

  const res = await query(
    `
    INSERT INTO cex_trades (
      exchange_id,
      symbol,
      trade_id,
      time_stamp,
      side,
      price,
      amount_base,
      cost_quote,
      fee_quote,
      payload
    )
    VALUES ${placeholders.join(',')}
    ON CONFLICT (exchange_id, symbol, trade_id) DO NOTHING
    `,
    values
  );
  return res.rowCount || 0;
};

const upsertDailyStats = async (exchangeId, symbol, ohlcvRows) => {
  if (!Array.isArray(ohlcvRows) || ohlcvRows.length === 0) return 0;

  const values = [];
  const placeholders = [];
  let idx = 1;

  for (const row of ohlcvRows) {
    if (!Array.isArray(row) || row.length < 6) continue;
    const [ms, open, high, low, close, volumeBase] = row;
    const ts = toTimestamptz(ms);
    if (!ts) continue;
    const day = ts.toISOString().slice(0, 10);
    const volumeQuote = volumeBase != null && close != null ? Number(volumeBase) * Number(close) : null;

    placeholders.push(
      `($${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++})`
    );
    values.push(
      day,
      exchangeId,
      symbol,
      open ?? null,
      high ?? null,
      low ?? null,
      close ?? null,
      volumeBase ?? null,
      volumeQuote,
      row
    );
  }

  if (!placeholders.length) return 0;

  const res = await query(
    `
    INSERT INTO cex_daily_stats (
      day,
      exchange_id,
      symbol,
      open,
      high,
      low,
      close,
      volume_base,
      volume_quote,
      payload
    )
    VALUES ${placeholders.join(',')}
    ON CONFLICT (day, exchange_id, symbol) DO UPDATE
    SET open = EXCLUDED.open,
        high = EXCLUDED.high,
        low = EXCLUDED.low,
        close = EXCLUDED.close,
        volume_base = EXCLUDED.volume_base,
        volume_quote = EXCLUDED.volume_quote,
        payload = EXCLUDED.payload
    `,
    values
  );

  return res.rowCount || 0;
};

const syncMarketOnce = async (market, logger) => {
  const exchangeId = normalizeExchangeId(market.exchangeId);
  const symbol = market.symbol;
  const key = `${exchangeId}:${symbol}`;

  if (!exchangeId || !symbol) return;
  if (!backoffAllows(key)) return;

  const exchange = getExchangeInstance(exchangeId);
  if (!exchange) {
    await setIngestState({
      exchangeId,
      symbol,
      lastError: `Exchange not supported by CCXT: ${exchangeId}`,
    });
    bumpBackoff(key);
    return;
  }

  try {
    await exchange.loadMarkets();
  } catch (error) {
    const delay = bumpBackoff(key);
    await setIngestState({
      exchangeId,
      symbol,
      lastError: `loadMarkets failed: ${error.message || String(error)} (backoff ${delay}ms)`,
    });
    logger?.warn?.(`! CEX ${key} loadMarkets failed:`, error.message || error);
    return;
  }

  if (!exchange.markets || !exchange.markets[symbol]) {
    const delay = bumpBackoff(key);
    await setIngestState({
      exchangeId,
      symbol,
      lastError: `Market not found: ${symbol} (backoff ${delay}ms)`,
    });
    logger?.warn?.(`! CEX ${key} market not found (${symbol})`);
    return;
  }

  const state = await getIngestState(exchangeId, symbol);
  const lastTsMs = state?.lastTradeTsMs ? Number(state.lastTradeTsMs) : 0;
  let since = lastTsMs > 0 ? Math.max(0, lastTsMs - 60_000) : undefined;
  if (since !== undefined && exchangeId === 'mexc') {
    // MEXC rejects fetchTrades windows > ~1h; clamp lookback so ingestion doesn't wedge after downtime.
    const earliest = Date.now() - 55 * 60_000;
    since = Math.max(since, earliest);
  }

  try {
    // Some CCXT exchanges (notably mexc) require an `until` param when `since` is provided.
    const params = since !== undefined && exchangeId === 'mexc' ? { until: Date.now() } : undefined;
    const trades = await exchange.fetchTrades(symbol, since, CEX_TRADE_LIMIT, params);
    const inserted = await insertTrades(exchangeId, symbol, trades);

    let maxTs = lastTsMs;
    let lastTradeId = state?.lastTradeId || null;
    for (const t of trades || []) {
      const ts = Number(t?.timestamp || 0);
      if (Number.isFinite(ts) && ts > maxTs) {
        maxTs = ts;
        lastTradeId = t?.id ? String(t.id) : lastTradeId;
      }
    }

    const now = Date.now();
    const lastOhlcvAtMs = state?.lastOhlcvFetchAt ? new Date(state.lastOhlcvFetchAt).getTime() : 0;
    const shouldFetchOhlcv = CEX_OHLCV_REFRESH_MS > 0 && (!lastOhlcvAtMs || now - lastOhlcvAtMs >= CEX_OHLCV_REFRESH_MS);

    if (shouldFetchOhlcv && exchange.has?.fetchOHLCV) {
      try {
        const ohlcv = await exchange.fetchOHLCV(symbol, '1d', undefined, 60);
        await upsertDailyStats(exchangeId, symbol, ohlcv);
        await setIngestState({
          exchangeId,
          symbol,
          lastTradeTsMs: maxTs || lastTsMs || null,
          lastTradeId,
          lastOhlcvFetchAt: new Date(),
          lastError: null,
        });
      } catch (error) {
        await setIngestState({
          exchangeId,
          symbol,
          lastTradeTsMs: maxTs || lastTsMs || null,
          lastTradeId,
          lastError: `fetchOHLCV failed: ${error.message || String(error)}`,
        });
      }
    } else {
      await setIngestState({
        exchangeId,
        symbol,
        lastTradeTsMs: maxTs || lastTsMs || null,
        lastTradeId,
        lastError: null,
      });
    }

    clearBackoff(key);
    if (inserted > 0) {
      logger?.log?.(`✓ CEX ${key} inserted ${inserted} trade(s)`);
    }
  } catch (error) {
    const delay = bumpBackoff(key);
    await setIngestState({
      exchangeId,
      symbol,
      lastError: `fetchTrades failed: ${error.message || String(error)} (backoff ${delay}ms)`,
    });
    logger?.warn?.(`! CEX ${key} fetchTrades failed:`, error.message || error);
  }
};

let pollTimer = null;
let running = false;

const startCexIngestion = async ({ logger = console } = {}) => {
  if (!CEX_ENABLED) {
    logger.log('ℹ️  CEX ingestion disabled (CEX_ENABLED!=1)');
    return { started: false };
  }

  if (!getDbPool()) {
    logger.warn('! CEX ingestion skipped: database not configured');
    return { started: false };
  }

  await cexTradesService.bootstrapCexMarketsFromEnv();

  if (running) return { started: true };
  running = true;

  const tick = async () => {
    try {
      const markets = await getActiveMarkets();
      if (!markets.length) {
        logger.warn('! CEX ingestion: no active markets configured (set CEX_MARKETS or insert into cex_markets)');
        return;
      }
      await mapWithConcurrency(markets, CEX_CONCURRENCY, async (market) => syncMarketOnce(market, logger));
    } catch (error) {
      logger.warn('! CEX ingestion tick failed:', error.message || error);
    }
  };

  await tick();

  if (CEX_TRADE_POLL_INTERVAL_MS > 0) {
    pollTimer = setInterval(tick, CEX_TRADE_POLL_INTERVAL_MS);
  }

  logger.log(
    `✓ CEX ingestion started (exchanges=${CEX_EXCHANGES.join(',') || 'none'}, poll=${CEX_TRADE_POLL_INTERVAL_MS}ms)`
  );
  return { started: true };
};

const stopCexIngestion = () => {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
  running = false;
};

module.exports = {
  startCexIngestion,
  stopCexIngestion,
};

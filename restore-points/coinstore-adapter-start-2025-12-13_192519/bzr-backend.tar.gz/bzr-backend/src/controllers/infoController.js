const { query } = require('../utils/db');
const tokenService = require('../services/tokenService');
const {
  getNextApiKey,
  respondUpstreamFailure,
  hasApiKeys,
  markApiKeyAsFailed,
  shouldBackoffApiKey,
} = require('../utils/apiUtils');
const axios = require('axios');
const { PROVIDERS } = require('../config/chains');
const { getTokenAddress } = require('../services/configService');
const BUNDLE_BASE_URL = process.env.BZR_BUNDLE_BASE_URL || 'https://bzr-bundle.info-exchangepro3617.workers.dev';
const BUNDLE_CIRC_OVERRIDE = Number(process.env.BZR_BUNDLE_CIRC_OVERRIDE || 56_105_556.748519213);
const BUNDLE_MAX_OVERRIDE = Number(process.env.BZR_BUNDLE_MAX_OVERRIDE || 555_555_555.5555556);

const API_V2_BASE_URL = PROVIDERS.etherscan.baseUrl;

const fetchBundleCirculating = async () => {
  if (!BUNDLE_BASE_URL) return null;
  try {
    const resp = await axios.get(`${BUNDLE_BASE_URL}/circulating`, { timeout: 7_500 });
    const num = Number(resp?.data);
    if (Number.isFinite(num) && num !== 0) {
      return Math.abs(num); // guard against negative/odd upstream responses
    }
  } catch (err) {
    console.warn('! Bundle circulating fetch failed:', err.message);
  }
  return Number.isFinite(BUNDLE_CIRC_OVERRIDE) ? BUNDLE_CIRC_OVERRIDE : null;
};

const fetchBundleMax = async () => {
  if (!BUNDLE_BASE_URL) return null;
  try {
    const resp = await axios.get(`${BUNDLE_BASE_URL}/maxcoins`, { timeout: 7_500 });
    const num = Number(resp?.data);
    if (Number.isFinite(num) && num !== 0) {
      return Math.abs(num);
    }
  } catch (err) {
    console.warn('! Bundle max fetch failed:', err.message);
  }
  return Number.isFinite(BUNDLE_MAX_OVERRIDE) ? BUNDLE_MAX_OVERRIDE : null;
};

/**
 * Get token information (supply, details, etc.)
 * GET /api/info
 */
const getTokenInfo = async (req, res) => {
  console.log(`[${new Date().toISOString()}] Received request for /api/info`);
  const tokenAddress = getTokenAddress();
  const bundleCirculating = await fetchBundleCirculating();
  const bundleMax = await fetchBundleMax();
  
  // Check if force refresh requested
  const forceRefresh = req.query.force === 'true';
  
  if (!tokenAddress) {
    return res.status(500).json({ message: 'Token address is not configured' });
  }

  if (!hasApiKeys()) {
    return res.status(500).json({ message: 'Server is missing ETHERSCAN_V2_API_KEY' });
  }

  const apiKey = getNextApiKey();
  if (!apiKey) {
    return res.status(503).json({ message: 'All Etherscan API keys are currently rate limited or unavailable' });
  }

  try {
    // Step 1: Try to get from database (unless force refresh)
    if (!forceRefresh) {
      const dbResult = await query(
        `SELECT 
          token_name, token_symbol, token_decimals,
          total_supply, formatted_total_supply,
          circulating_supply, formatted_circulating_supply,
          updated_at
         FROM token_info 
         WHERE contract_address = $1 
         AND updated_at > NOW() - INTERVAL '1 hour'
         LIMIT 1`,
        [tokenAddress.toLowerCase()]
      );

      if (dbResult.rows.length > 0) {
        const row = dbResult.rows[0];
        const tokenInfo = {
          tokenName: row.token_name,
          tokenSymbol: row.token_symbol,
          tokenDecimal: row.token_decimals,
          totalSupply: row.total_supply,
          circulatingSupply: row.circulating_supply,
          formattedTotalSupply: row.formatted_total_supply,
          formattedCirculatingSupply: row.formatted_circulating_supply,
          _source: 'database',
          _updatedAt: row.updated_at,
        };
        console.log(`-> Returning token info from database (updated ${row.updated_at})`);
        return res.json(tokenInfo);
      } else {
        console.log('-> No recent token info in database, fetching from upstream...');
      }
    } else {
      console.log('-> Force refresh requested, bypassing database cache');
    }

    // Step 2: Fetch from upstream (either no DB data, stale, or forced)
    const params = {
      chainid: 1, // Ethereum Mainnet
      apikey: apiKey,
    };

    // Call 1: Get Total Supply
    const supplyParams = {
      ...params,
      module: 'stats',
      action: 'tokensupply',
      contractaddress: tokenAddress,
      contractaddress: tokenAddress,
    };

    // Call 2: Get token details (name, symbol, decimals) from the last transaction
    const txParams = {
      ...params,
      module: 'account',
      action: 'tokentx',
      contractaddress: tokenAddress,
      contractaddress: tokenAddress,
      page: 1,
      offset: 1,
      sort: 'desc',
    };

    // Call 3: Get detailed token info including circulating supply
    const tokenInfoParams = {
      ...params,
      module: 'token',
      action: 'tokeninfo',
      contractaddress: tokenAddress,
      contractaddress: tokenAddress,
    };

    console.log('-> Fetching token info from Etherscan API...');
    const [supplyResponse, txResponse, tokenInfoResponse] = await Promise.all([
      axios.get(API_V2_BASE_URL, { params: supplyParams, timeout: 15000 }),
      axios.get(API_V2_BASE_URL, { params: txParams, timeout: 15000 }),
      axios.get(API_V2_BASE_URL, { params: tokenInfoParams, timeout: 15000 }),
    ]);

    // Check for API errors
    if (supplyResponse.data.status !== '1' || txResponse.data.status !== '1') {
      console.error('Etherscan API Error:', supplyResponse.data.message, txResponse.data.message);
      
      // If upstream fails, try to return stale DB data as fallback
      const fallbackResult = await query(
        `SELECT 
          token_name, token_symbol, token_decimals,
          total_supply, formatted_total_supply,
          circulating_supply, formatted_circulating_supply,
          updated_at
         FROM token_info 
        WHERE contract_address = $1 
        ORDER BY updated_at DESC
        LIMIT 1`,
        [tokenAddress.toLowerCase()]
      );

      if (fallbackResult.rows.length > 0) {
        const row = fallbackResult.rows[0];
        const tokenInfo = {
          tokenName: row.token_name,
          tokenSymbol: row.token_symbol,
          tokenDecimal: row.token_decimals,
          totalSupply: row.total_supply,
          circulatingSupply: row.circulating_supply,
          formattedTotalSupply: row.formatted_total_supply,
          formattedCirculatingSupply: row.formatted_circulating_supply,
          _source: 'database_fallback',
          _updatedAt: row.updated_at,
          _warning: 'Upstream API unavailable, showing cached data',
        };
        console.log(`-> Upstream failed, returning stale DB data from ${row.updated_at}`);
        return res.json(tokenInfo);
      }

      return respondUpstreamFailure(res, 'Upstream Etherscan API error while fetching token info', {
        supplyError: supplyResponse.data.message,
        txError: txResponse.data.message,
        tokenInfoError: tokenInfoResponse.data.message,
      });
    }

    // --- Parse the data ---
    const totalSupply = supplyResponse.data.result;
    const lastTx = txResponse.data.result[0];
    
    if (!lastTx) {
      return res.status(404).json({ message: 'No transactions found for this token to read info from.' });
    }

    const { tokenName, tokenSymbol, tokenDecimal } = lastTx;
    
    // Data from Token Info call (includes circulating supply)
    let circulatingSupply = null;
    let formattedCirculatingSupply = null;
    const decimalsInt = parseInt(tokenDecimal || '18', 10) || 18;
    if (tokenInfoResponse.data.status === '1' && Array.isArray(tokenInfoResponse.data.result)) {
      const tokenInfoData = tokenInfoResponse.data.result[0];
      if (tokenInfoData && tokenInfoData.circulatingSupply) {
        circulatingSupply = tokenInfoData.circulatingSupply;
        try {
          formattedCirculatingSupply = (BigInt(circulatingSupply) / BigInt(10 ** decimalsInt)).toString();
        } catch (e) {
          console.warn('! Could not format circulating supply:', e.message);
        }
      }
    }

    // Override with bundle circulating if available (bundle returns human-readable tokens)
    if (bundleCirculating !== null) {
      try {
        const micro = Math.round(bundleCirculating * 1_000_000);
        const raw =
          decimalsInt >= 6
            ? BigInt(micro) * (BigInt(10) ** BigInt(decimalsInt - 6))
            : BigInt(Math.round(bundleCirculating * Math.pow(10, decimalsInt)));
        circulatingSupply = raw.toString();
        formattedCirculatingSupply = bundleCirculating.toString();
      } catch (e) {
        console.warn('! Failed to apply bundle circulating supply:', e.message);
      }
    }

    console.log(
      `-> Circulating supply selection | bundle=${bundleCirculating} | formatted=${formattedCirculatingSupply} | raw=${circulatingSupply}`
    );

    // Override total supply with bundle max if available
    let totalSupplyRaw = totalSupply;
    let formattedTotalSupply = null;
    const decimalsForTotal = parseInt(tokenDecimal, 10) || decimalsInt;
    if (bundleMax !== null) {
      try {
        const micro = Math.round(bundleMax * 1_000_000);
        const raw =
          decimalsForTotal >= 6
            ? BigInt(micro) * (BigInt(10) ** BigInt(decimalsForTotal - 6))
            : BigInt(Math.round(bundleMax * Math.pow(10, decimalsForTotal)));
        totalSupplyRaw = raw.toString();
        formattedTotalSupply = bundleMax.toString();
      } catch (e) {
        console.warn('! Failed to apply bundle max supply:', e.message);
      }
    }
    if (!formattedTotalSupply) {
      formattedTotalSupply = (BigInt(totalSupplyRaw) / BigInt(10 ** decimalsForTotal)).toString();
    }
    
    // Step 3: Persist to database
    try {
      await query(
        `INSERT INTO token_info (
          contract_address, chain_id, token_name, token_symbol, token_decimals,
          total_supply, formatted_total_supply,
          circulating_supply, formatted_circulating_supply,
          source_data, last_fetch_success, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, true, NOW())
        ON CONFLICT (contract_address) 
        DO UPDATE SET
          chain_id = EXCLUDED.chain_id,
          token_name = EXCLUDED.token_name,
          token_symbol = EXCLUDED.token_symbol,
          token_decimals = EXCLUDED.token_decimals,
          total_supply = EXCLUDED.total_supply,
          formatted_total_supply = EXCLUDED.formatted_total_supply,
          circulating_supply = EXCLUDED.circulating_supply,
          formatted_circulating_supply = EXCLUDED.formatted_circulating_supply,
          source_data = EXCLUDED.source_data,
          last_fetch_success = true,
          last_fetch_error = NULL,
          updated_at = NOW()`,
        [
          tokenAddress.toLowerCase(),
          1, // Ethereum Mainnet
          tokenName,
          tokenSymbol,
          parseInt(tokenDecimal, 10),
          totalSupplyRaw,
          formattedTotalSupply,
          circulatingSupply,
          formattedCirculatingSupply,
          JSON.stringify({
            supplyResponse: supplyResponse.data,
            txResponse: txResponse.data,
            tokenInfoResponse: tokenInfoResponse.data,
            bundleMax,
            bundleCirculating,
          }),
        ]
      );
      console.log('-> Token info persisted to database');
    } catch (dbError) {
      console.error('! Failed to persist token info to database:', dbError.message);
      // Continue anyway - upstream data is still valid
    }

    // --- Send Response ---
    const tokenInfo = {
      tokenName,
      tokenSymbol,
      tokenDecimal: parseInt(tokenDecimal, 10),
      totalSupply: totalSupplyRaw,
      circulatingSupply,
      formattedTotalSupply,
      formattedCirculatingSupply,
      _source: 'upstream',
    };

    console.log('-> Successfully fetched token info from upstream and persisted to DB');
    res.json(tokenInfo);

  } catch (error) {
    if (shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: 'info_endpoint_rate_limit' });
    }
    console.error('Error in /api/info handler:', error.message);

    // Fallback to bundle circulating if available (even when upstream fails)
    if (bundleCirculating !== null) {
      const decimalsInt = 18;
      let circRaw = null;
      try {
        const micro = Math.round(bundleCirculating * 1_000_000);
        circRaw = (BigInt(micro) * (BigInt(10) ** BigInt(decimalsInt - 6))).toString();
      } catch (e) {
        console.warn('! Failed to compute raw from bundle in error path:', e.message);
      }
      const formattedCirculatingSupply = bundleCirculating.toString();
      if (circRaw) {
        try {
          await query(
            `INSERT INTO token_info (
              contract_address, chain_id, token_name, token_symbol, token_decimals,
              total_supply, formatted_total_supply,
              circulating_supply, formatted_circulating_supply,
              source_data, last_fetch_success, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, false, NOW())
            ON CONFLICT (contract_address) 
            DO UPDATE SET
              chain_id = EXCLUDED.chain_id,
              circulating_supply = EXCLUDED.circulating_supply,
              formatted_circulating_supply = EXCLUDED.formatted_circulating_supply,
              source_data = EXCLUDED.source_data,
              last_fetch_success = false,
              last_fetch_error = $11,
              updated_at = NOW()`,
            [
              tokenAddress.toLowerCase(),
              1,
              null,
              null,
              decimalsInt,
              null,
              null,
              circRaw,
              formattedCirculatingSupply,
              JSON.stringify({ bundleCirculating, error: error.message }),
              error.message,
            ]
          );
        } catch (dbErr) {
          console.warn('! Failed to persist bundle fallback:', dbErr.message);
        }
        return res.json({
          tokenName: null,
          tokenSymbol: null,
          tokenDecimal: decimalsInt,
          totalSupply: null,
          circulatingSupply: circRaw,
          formattedTotalSupply: null,
          formattedCirculatingSupply,
          _source: 'bundle_fallback',
          _warning: 'Upstream failed; showing bundle circulating supply',
        });
      }
    }
    
    // Last resort: try to return any DB data we have
    try {
      const emergencyResult = await query(
        `SELECT 
          token_name, token_symbol, token_decimals,
          total_supply, formatted_total_supply,
          circulating_supply, formatted_circulating_supply,
          updated_at
         FROM token_info 
         WHERE contract_address = $1 
         ORDER BY updated_at DESC
         LIMIT 1`,
        [tokenAddress.toLowerCase()]
      );

      if (emergencyResult.rows.length > 0) {
        const row = emergencyResult.rows[0];
        const tokenInfo = {
          tokenName: row.token_name,
          tokenSymbol: row.token_symbol,
          tokenDecimal: row.token_decimals,
          totalSupply: row.total_supply,
          circulatingSupply: row.circulating_supply,
          formattedTotalSupply: row.formatted_total_supply,
          formattedCirculatingSupply: row.formatted_circulating_supply,
          _source: 'database_emergency',
          _updatedAt: row.updated_at,
          _warning: 'Error occurred, showing last known data',
        };
        console.log(`-> Emergency fallback: returning DB data from ${row.updated_at}`);
        return res.json(tokenInfo);
      }
    } catch (fallbackError) {
      console.error('! Emergency fallback also failed:', fallbackError.message);
    }

    if (error.response?.data) {
      return respondUpstreamFailure(res, 'Failed to fetch token info from Etherscan', {
        upstreamResponse: error.response.data,
      });
    }

    res.status(500).json({ message: 'Failed to fetch token info', error: error.message });
  }
};

/**
 * Get token price
 * GET /api/price
 */
const getTokenPrice = async (req, res) => {
  try {
    const priceData = await tokenService.fetchTokenPrice();
    res.json(priceData);
  } catch (error) {
    console.error('Error fetching token price:', error);
    res.status(500).json({ error: 'Failed to fetch token price' });
  }
};

module.exports = {
  getTokenInfo,
  getTokenPrice,
};

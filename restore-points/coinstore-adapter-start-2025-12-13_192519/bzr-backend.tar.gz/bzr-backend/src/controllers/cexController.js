'use strict';

const cexTradesService = require('../services/cexTradesService');

const getMarkets = async (req, res) => {
  try {
    const activeOnly = req.query.activeOnly !== 'false';
    const markets = await cexTradesService.listCexMarkets({ activeOnly });
    res.json({ data: markets, timestamp: Date.now() });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to fetch CEX markets',
      error: error.message || String(error),
    });
  }
};

const getTrades = async (req, res) => {
  const exchangeId = req.query.exchangeId ? String(req.query.exchangeId).trim() : undefined;
  const symbol = req.query.symbol ? String(req.query.symbol).trim() : undefined;
  const page = Math.max(1, Number(req.query.page || 1));
  const pageSize = Math.min(200, Math.max(10, Number(req.query.pageSize || 25)));
  const sortParam = typeof req.query.sort === 'string' ? req.query.sort.toLowerCase() : 'desc';
  const sort = sortParam === 'asc' ? 'asc' : 'desc';

  try {
    const result = await cexTradesService.fetchCexTrades({
      exchangeId,
      symbol,
      page,
      pageSize,
      sort,
    });
    res.json(result);
  } catch (error) {
    res.status(500).json({
      message: 'Failed to fetch CEX trades',
      error: error.message || String(error),
    });
  }
};

const getDailyVolume = async (req, res) => {
  const exchangeId = req.query.exchangeId ? String(req.query.exchangeId).trim() : undefined;
  const symbol = req.query.symbol ? String(req.query.symbol).trim() : undefined;
  const days = Number(req.query.days || 30);

  try {
    const result = await cexTradesService.fetchCexDailyVolume({
      exchangeId,
      symbol,
      days,
    });
    res.json(result);
  } catch (error) {
    res.status(500).json({
      message: 'Failed to fetch CEX volume',
      error: error.message || String(error),
    });
  }
};

module.exports = {
  getMarkets,
  getTrades,
  getDailyVolume,
};


'use strict';

const axios = require('axios');
const { 
  CHAINS, 
  PROVIDERS,
  getChainDefinition, 
  getProviderKeyForChain, 
  getProviderConfigForChain, 
  buildProviderRequest 
} = require('../config/chains');
const { getNextApiKey, markApiKeyAsFailed, shouldBackoffApiKey } = require('../utils/apiUtils');
const { getTokenAddress } = require('../services/configService');

const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';
const TRANSFER_EVENT_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';

const BZR_TOKEN_NAME = process.env.BZR_TOKEN_NAME || 'Bazaars';
const BZR_TOKEN_SYMBOL = process.env.BZR_TOKEN_SYMBOL || 'BZR';
const BZR_TOKEN_DECIMALS = Number(process.env.BZR_TOKEN_DECIMALS || 18);

const CRONOS_MAX_LOG_BLOCK_RANGE = Number(process.env.CRONOS_LOG_BLOCK_RANGE || 9_999);
const CRONOS_MAX_LOG_ITERATIONS = Number(process.env.CRONOS_LOG_MAX_ITERATIONS || 12);
const CRONOS_TOTAL_MAX_ITERATIONS = Number(process.env.CRONOS_TOTAL_LOG_MAX_ITERATIONS || 60);
const TRANSFERS_TOTAL_FETCH_LIMIT = Number(process.env.TRANSFERS_TOTAL_FETCH_LIMIT || 10000);

const normalizeHex = (value) => {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      return '0x0';
    }
    return `0x${value.toString(16)}`;
  }

  if (typeof value === 'bigint') {
    return `0x${value.toString(16)}`;
  }

  if (typeof value === 'string') {
    return value.startsWith('0x') || value.startsWith('0X') ? value : `0x${value}`;
  }

  return '0x0';
};

const hexToBigInt = (value) => {
  try {
    return BigInt(normalizeHex(value));
  } catch (error) {
    return BigInt(0);
  }
};

const hexToDecimalString = (value) => hexToBigInt(value).toString(10);

const hexToNumberSafe = (value) => {
  const normalized = normalizeHex(value);
  const parsed = Number.parseInt(normalized, 16);
  return Number.isFinite(parsed) ? parsed : 0;
};

const topicToAddress = (topic) => {
  if (typeof topic !== 'string' || topic.length < 42) {
    return ZERO_ADDRESS;
  }

  const trimmed = topic.slice(-40);
  return `0x${trimmed.toLowerCase()}`;
};

const clampTransfersPageSize = (value) => {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) {
    return 25;
  }

  const max = Number(process.env.TRANSFERS_MAX_PAGE_SIZE || 100);
  const min = 1;
  return Math.max(min, Math.min(Math.floor(numeric), max));
};

const normalizePageNumber = (value) => {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return 1;
  }

  return Math.floor(numeric);
};

const sanitizeTransfers = (transfers, chain) => {
  if (!Array.isArray(transfers)) {
    return [];
  }

  const sanitized = [];
  for (const tx of transfers) {
    if (!tx || typeof tx.timeStamp === 'undefined') {
      continue;
    }

    const numericTimestamp = Number(tx.timeStamp);
    if (!Number.isFinite(numericTimestamp)) {
      continue;
    }

    sanitized.push({
      ...tx,
      chainName: chain.name,
      chainId: chain.id,
      timeStamp: String(tx.timeStamp),
    });
  }

  return sanitized;
};

const isProOnlyResponse = (payload = {}) => {
  const segments = [];
  if (typeof payload === 'string') {
    segments.push(payload);
  } else {
    if (payload?.message) segments.push(payload.message);
    if (payload?.result) segments.push(typeof payload.result === 'string' ? payload.result : JSON.stringify(payload.result));
  }

  const combined = segments.join(' ').toLowerCase();
  return combined.includes('pro') && (combined.includes('endpoint') || combined.includes('plan'));
};

const fetchLatestBlockNumberForChain = async (chain) => {
  // Cronos Blockscout uses module=block&action=eth_block_number instead of proxy
  const blockNumberParams =
    getProviderKeyForChain(chain) === 'cronos'
      ? { module: 'block', action: 'eth_block_number' }
      : { module: 'proxy', action: 'eth_blockNumber' };

  const { provider, params, apiKey } = buildProviderRequest(chain, blockNumberParams);

  try {
    const response = await axios.get(provider.baseUrl, { params });
    const payload = response?.data || {};
    if (typeof payload.result === 'string') {
      return hexToNumberSafe(payload.result);
    }

    const error = new Error(payload?.message || 'Invalid block number payload');
    error.code = 'PROXY_BLOCKNUMBER_INVALID';
    error.payload = payload;
    throw error;
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `block_number_${chain.id}_rate_limit` });
    }
    if (error.response?.data) {
      const wrapped = new Error(error.message || 'Failed to fetch latest block number');
      wrapped.code = 'PROXY_BLOCKNUMBER_HTTP_ERROR';
      wrapped.payload = error.response.data;
      throw wrapped;
    }

    throw error;
  }
};

const fetchCronosLogsWindow = async (chain, fromBlock, toBlock) => {
  const tokenAddress = getTokenAddress();
  if (!tokenAddress) {
    throw new Error('Token address is not configured');
  }

  const baseProvider = getProviderConfigForChain(chain);
  const { provider, params } = buildProviderRequest(chain, {
    module: 'logs',
    action: 'getLogs',
    fromBlock,
    toBlock,
    address: tokenAddress,
    topic0: TRANSFER_EVENT_TOPIC,
  });

  // Use logsBaseUrl for cronos if provided, otherwise default baseUrl
  const targetBase = baseProvider.logsBaseUrl || provider.baseUrl;

  const response = await axios.get(targetBase, { params });
  const payload = response?.data || {};

  return {
    payload,
    request: {
      fromBlock,
      toBlock,
    },
  };
};

const mapCronosLogToTransfer = (log, chain, latestBlockNumber) => {
  const blockNumber = hexToNumberSafe(log.blockNumber);
  const timeStamp = hexToNumberSafe(log.timeStamp);
  const transactionIndex = hexToNumberSafe(log.transactionIndex);
  const logIndex = hexToNumberSafe(log.logIndex);
  const gasUsed = hexToDecimalString(log.gasUsed || '0x0');
  const gasPrice = hexToDecimalString(log.gasPrice || '0x0');
  const confirmations = latestBlockNumber >= blockNumber
    ? String(Math.max(0, latestBlockNumber - blockNumber))
    : '0';

  return {
    blockNumber: String(blockNumber),
    timeStamp: String(timeStamp),
    hash: log.transactionHash,
    nonce: '0',
    blockHash: log.blockHash,
    from: topicToAddress(log.topics?.[1]),
    contractAddress: log.address,
    to: topicToAddress(log.topics?.[2]),
    value: hexToDecimalString(log.data || '0x0'),
    tokenName: BZR_TOKEN_NAME,
    tokenSymbol: BZR_TOKEN_SYMBOL,
    tokenDecimal: String(BZR_TOKEN_DECIMALS),
    transactionIndex: String(transactionIndex),
    gas: gasUsed,
    gasPrice,
    gasUsed,
    cumulativeGasUsed: gasUsed,
    input: '0x',
    methodId: '0x',
    functionName: 'Transfer(address,address,uint256)',
    confirmations,
    logIndex: String(logIndex),
  };
};

const fetchCronosTransfersPage = async ({
  chain,
  page,
  pageSize,
  sort,
  startBlock,
  endBlock,
}) => {
  const normalizedPage = normalizePageNumber(page);
  const normalizedPageSize = clampTransfersPageSize(pageSize);
  const latestBlockNumber = await fetchLatestBlockNumberForChain(chain);
  const effectiveEnd = typeof endBlock === 'number' ? endBlock : latestBlockNumber;
  const effectiveStart = typeof startBlock === 'number' ? startBlock : 0;

  let currentTo = effectiveEnd;
  let iterations = 0;
  const collected = [];
  const batches = [];
  const requiredItems = normalizedPage * normalizedPageSize + normalizedPageSize;

  while (
    currentTo >= effectiveStart &&
    iterations < CRONOS_MAX_LOG_ITERATIONS &&
    collected.length < requiredItems
  ) {
    const span = CRONOS_MAX_LOG_BLOCK_RANGE > 0 ? CRONOS_MAX_LOG_BLOCK_RANGE : 9_999;
    const currentFrom = Math.max(effectiveStart, currentTo - (span - 1));
    const { payload, request } = await fetchCronosLogsWindow(chain, currentFrom, currentTo);
    const resultLength = Array.isArray(payload.result) ? payload.result.length : 0;

    batches.push({
      ...request,
      status: payload.status,
      message: payload.message,
      resultLength,
    });

    if (payload.status === '1' && Array.isArray(payload.result)) {
      collected.push(...payload.result);
    } else if (payload.status === '0') {
      const message = String(payload.message || payload.result || '').toLowerCase();
      if (!(message.includes('no records') || message.includes('no logs'))) {
        const error = new Error(payload.message || payload.result || 'Failed to fetch Cronos token transfers');
        error.code = 'CRONOS_LOGS_ERROR';
        error.payload = payload;
        throw error;
      }
    } else {
      const error = new Error('Unexpected response from Cronos logs endpoint');
      error.code = 'CRONOS_LOGS_UNEXPECTED_RESPONSE';
      error.payload = payload;
      throw error;
    }

    iterations += 1;
    currentTo = currentFrom - 1;
  }

  const decorated = collected.map((log) => ({
    log,
    blockNumber: hexToNumberSafe(log.blockNumber),
    timeStamp: hexToNumberSafe(log.timeStamp),
  }));

  decorated.sort((a, b) => {
    const comparator = sort === 'asc' ? 1 : -1;
    if (a.blockNumber !== b.blockNumber) {
      return comparator * (a.blockNumber - b.blockNumber);
    }

    return comparator * (a.timeStamp - b.timeStamp);
  });

  const startIndex = (normalizedPage - 1) * normalizedPageSize;
  const pageLogs = decorated.slice(startIndex, startIndex + normalizedPageSize).map((entry) => entry.log);
  const mapped = pageLogs.map((log) => mapCronosLogToTransfer(log, chain, latestBlockNumber));
  const transfers = sanitizeTransfers(mapped, chain);

  return {
    transfers,
    upstream: {
      provider: 'cronos',
      latestBlock: latestBlockNumber,
      iterations,
      batches,
      collected: collected.length,
    },
    timestamp: Date.now(),
    page: normalizedPage,
    pageSize: normalizedPageSize,
    sort,
    startBlock,
    endBlock,
    resultLength: transfers.length,
    totalCollected: decorated.length,
  };
};

const fetchCronosTransfersTotalCount = async ({ chain, startBlock, endBlock, limit = Number(process.env.TRANSFERS_TOTAL_FETCH_LIMIT || 25_000) }) => {
  const latestBlockNumber = await fetchLatestBlockNumberForChain(chain);
  const effectiveEnd = typeof endBlock === 'number' ? endBlock : latestBlockNumber;
  const effectiveStart = typeof startBlock === 'number' ? startBlock : 0;

  const isAllTimeQuery = typeof startBlock !== 'number' && typeof endBlock !== 'number';
  if (isAllTimeQuery) {
    return {
      total: limit,
      truncated: true,
      timestamp: Date.now(),
      resultLength: limit,
      estimated: true,
      upstream: {
        provider: 'cronos',
        iterations: 0,
        batches: [],
        latestBlock: latestBlockNumber,
        note: 'All-time count estimation to prevent timeout',
      },
    };
  }

  let currentTo = effectiveEnd;
  let iterations = 0;
  let total = 0;
  let truncated = false;
  const batches = [];

  while (currentTo >= effectiveStart && iterations < CRONOS_TOTAL_MAX_ITERATIONS) {
    const span = CRONOS_MAX_LOG_BLOCK_RANGE > 0 ? CRONOS_MAX_LOG_BLOCK_RANGE : 9_999;
    const currentFrom = Math.max(effectiveStart, currentTo - (span - 1));
    const { payload, request } = await fetchCronosLogsWindow(chain, currentFrom, currentTo);
    const resultLength = Array.isArray(payload.result) ? payload.result.length : 0;

    batches.push({
      ...request,
      status: payload.status,
      message: payload.message,
      resultLength,
    });

    if (payload.status === '1' && Array.isArray(payload.result)) {
      total += resultLength;
      if (total >= limit) {
        truncated = true;
        total = limit;
        break;
      }
    } else if (payload.status === '0') {
      const message = String(payload.message || payload.result || '').toLowerCase();
      if (!(message.includes('no records') || message.includes('no logs'))) {
        const error = new Error(payload.message || payload.result || 'Failed to fetch Cronos transfers total');
        error.code = 'CRONOS_LOGS_TOTAL_ERROR';
        error.payload = payload;
        throw error;
      }
    } else {
      const error = new Error('Unexpected response from Cronos logs endpoint while counting');
      error.code = 'CRONOS_LOGS_TOTAL_UNEXPECTED_RESPONSE';
      error.payload = payload;
      throw error;
    }

    iterations += 1;
    currentTo = currentFrom - 1;
  }

  if (currentTo >= effectiveStart) {
    truncated = true;
  }

  return {
    total,
    truncated,
    timestamp: Date.now(),
    resultLength: total,
    upstream: {
      provider: 'cronos',
      iterations,
      batches,
      latestBlock: latestBlockNumber,
    },
  };
};

const fetchTransfersPageFromChain = async ({
  chain,
  page,
  pageSize,
  sort,
  startBlock,
  endBlock,
}) => {
  const tokenAddress = getTokenAddress();
  if (!tokenAddress) {
    throw new Error('Token address is not configured');
  }

  if (getProviderKeyForChain(chain) === 'cronos') {
    return fetchCronosTransfersPage({
      chain,
      page,
      pageSize,
      sort,
      startBlock,
      endBlock,
    });
  }

  const baseParams = {
    module: 'account',
    action: 'tokentx',
    contractaddress: tokenAddress,
    page,
    offset: pageSize,
    sort,
  };

  if (typeof startBlock === 'number') {
    baseParams.startblock = startBlock;
  }
  if (typeof endBlock === 'number') {
    baseParams.endblock = endBlock;
  }

  const baseProvider = getProviderConfigForChain(chain);
  const { provider, params, apiKey } = buildProviderRequest(chain, baseParams);

  try {
    const targetBase = baseProvider.logsBaseUrl || provider.baseUrl;
    const response = await axios.get(targetBase, { params });
    const payload = response?.data || {};

    if (payload.status === '1' && Array.isArray(payload.result)) {
      const sanitized = sanitizeTransfers(payload.result, chain);
      return {
        transfers: sanitized,
        upstream: payload,
        timestamp: Date.now(),
        page,
        pageSize,
        sort,
        startBlock,
        endBlock,
        resultLength: payload.result.length,
      };
    }

    if (payload.status === '0' || String(payload?.message || '').toUpperCase() === 'NOTOK') {
      const errorMessage = payload?.message || payload?.result || '';
      const errorString = String(errorMessage);

      if (isProOnlyResponse(payload)) {
        const error = new Error(payload?.result || payload?.message || 'Etherscan PRO plan required');
        error.code = 'ETHERSCAN_PRO_ONLY';
        error.payload = payload;
        throw error;
      }

      const noRecordsMessage = errorString.toLowerCase();
      if (noRecordsMessage.includes('no transactions') || noRecordsMessage.includes('no records found')) {
        return {
          transfers: [],
          upstream: payload,
          timestamp: Date.now(),
          page,
          pageSize,
          sort,
          startBlock,
          endBlock,
          resultLength: 0,
        };
      }

      const error = new Error(errorString || 'Failed to fetch token transfers');
      error.code = 'ETHERSCAN_ERROR';
      error.payload = payload;
      throw error;
    }

    const error = new Error('Unexpected response from Etherscan');
    error.code = 'ETHERSCAN_UNEXPECTED_RESPONSE';
    error.payload = payload;
    throw error;
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `transfers_page_${chain.id}_rate_limit` });
    }
    if (error.response?.data) {
      const wrappedError = new Error(error.message || 'Etherscan request failed');
      wrappedError.code = 'ETHERSCAN_HTTP_ERROR';
      wrappedError.payload = error.response.data;
      throw wrappedError;
    }

    throw error;
  }
};

const fetchTransfersTotalCount = async ({ chain, sort, startBlock, endBlock, limit = Number(process.env.TRANSFERS_TOTAL_FETCH_LIMIT || 10_000) }) => {
  const tokenAddress = getTokenAddress();
  if (!tokenAddress) {
    throw new Error('Token address is not configured');
  }

  if (getProviderKeyForChain(chain) === 'cronos') {
    return fetchCronosTransfersTotalCount({ chain, startBlock, endBlock, limit });
  }

  const baseParams = {
    module: 'account',
    action: 'tokentx',
    contractaddress: tokenAddress,
    sort,
    page: 1,
    offset: limit,
  };

  if (typeof startBlock === 'number') {
    baseParams.startblock = startBlock;
  }
  if (typeof endBlock === 'number') {
    baseParams.endblock = endBlock;
  }

  const { provider, params, apiKey } = buildProviderRequest(chain, baseParams);

  try {
    const response = await axios.get(provider.baseUrl, { params });
    const payload = response?.data || {};

    if (payload.status === '1' && Array.isArray(payload.result)) {
      return {
        total: payload.result.length,
        truncated: payload.result.length >= limit,
        timestamp: Date.now(),
        resultLength: payload.result.length,
        upstream: payload,
      };
    }

    if (payload.status === '0' || String(payload?.message || '').toUpperCase() === 'NOTOK') {
      if (isProOnlyResponse(payload)) {
        const error = new Error(payload?.result || payload?.message || 'Etherscan PRO plan required');
        error.code = 'ETHERSCAN_PRO_ONLY';
        error.payload = payload;
        throw error;
      }

      const errorMessage = payload?.message || payload?.result || 'Failed to count transfers';
      const error = new Error(errorMessage);
      error.code = 'ETHERSCAN_TOTAL_ERROR';
      error.payload = payload;
      throw error;
    }

    const error = new Error('Unexpected response from Etherscan when counting transfers');
    error.code = 'ETHERSCAN_TOTAL_UNEXPECTED_RESPONSE';
    error.payload = payload;
    throw error;
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `transfers_total_${chain.id}_rate_limit` });
    }
    throw error;
  }
};

module.exports = {
  BZR_TOKEN_NAME,
  BZR_TOKEN_SYMBOL,
  BZR_TOKEN_DECIMALS,
  TRANSFER_EVENT_TOPIC,
  ZERO_ADDRESS,
  CHAINS,
  PROVIDERS,
  getChainDefinition,
  getProviderKeyForChain,
  getProviderConfigForChain,
  buildProviderRequest,
  sanitizeTransfers,
  fetchTransfersPageFromChain,
  fetchTransfersTotalCount,
  fetchCronosTransfersPage,
  fetchCronosTransfersTotalCount,
  clampTransfersPageSize,
  normalizePageNumber,
  isProOnlyResponse,
  getNextApiKey,
  hexToNumberSafe,
  hexToDecimalString,
};

const express = require('express');
const cexController = require('../controllers/cexController');
const { strictLimiter } = require('../middleware/rateLimiters');
const cacheMiddleware = require('../middleware/cacheMiddleware');

const router = express.Router();

router.get('/markets', strictLimiter, cacheMiddleware(60), cexController.getMarkets);
router.get('/trades', strictLimiter, cacheMiddleware(15), cexController.getTrades);
router.get('/volume/daily', strictLimiter, cacheMiddleware(60), cexController.getDailyVolume);

module.exports = router;


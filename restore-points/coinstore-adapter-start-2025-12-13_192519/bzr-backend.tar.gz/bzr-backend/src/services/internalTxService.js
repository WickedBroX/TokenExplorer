'use strict';

const axios = require('axios');
const {
  CHAINS,
  getChainDefinition,
  getProviderKeyForChain,
  buildProviderRequest,
} = require('../config/chains');
const { getTokenAddress } = require('./configService');
const { mapWithConcurrency } = require('../utils/concurrency');
const { shouldBackoffApiKey, markApiKeyAsFailed } = require('../utils/apiUtils');

const INTERNAL_PAGE_TTL_MS = Number(process.env.INTERNAL_PAGE_TTL_MS || 2 * 60 * 1000);
const MAX_CONCURRENT_REQUESTS = Number(process.env.ETHERSCAN_CONCURRENCY || 3);

const internalPageCache = new Map(); // key -> { payload, timestamp }
const internalPagePromises = new Map(); // key -> promise

const buildInternalPageCacheKey = ({ chainId, page, pageSize, sort, address }) =>
  [chainId, page, pageSize, sort, address ? address.toLowerCase() : 'token'].join('|');

const getCachedInternalPage = (key) => {
  const entry = internalPageCache.get(key);
  if (!entry) return null;
  const age = Date.now() - entry.timestamp;
  return {
    payload: entry.payload,
    timestamp: entry.timestamp,
    stale: age > INTERNAL_PAGE_TTL_MS,
  };
};

const setCachedInternalPage = (key, payload) => {
  internalPageCache.set(key, { payload, timestamp: Date.now() });
};

const sanitizeInternalTransfers = (transfers, chain) => {
  if (!Array.isArray(transfers)) return [];
  return transfers
    .filter((tx) => tx && typeof tx.timeStamp !== 'undefined')
    .map((tx) => ({
      ...tx,
      chainId: chain.id,
      chainName: chain.name,
      timeStamp: String(tx.timeStamp),
    }));
};

const fetchInternalTransfersPageFromChain = async ({
  chain,
  page,
  pageSize,
  sort,
  address,
}) => {
  const targetAddress = address || getTokenAddress();
  if (!targetAddress) {
    const error = new Error('Token address is not configured');
    error.code = 'MISSING_TOKEN_ADDRESS';
    throw error;
  }

  if (getProviderKeyForChain(chain) === 'cronos') {
    const error = new Error(`Internal transactions not supported for ${chain.name} yet`);
    error.code = 'NOT_SUPPORTED';
    error.chainName = chain.name;
    throw error;
  }

  const { provider, params, apiKey } = buildProviderRequest(chain, {
    module: 'account',
    action: 'txlistinternal',
    address: targetAddress,
    page,
    offset: pageSize,
    sort,
  });

  try {
    const response = await axios.get(provider.baseUrl, { params, timeout: 10_000 });
    const payload = response?.data || {};
    const result = Array.isArray(payload.result) ? payload.result : [];

    if (payload.status === '0' && typeof payload.result === 'string') {
      const message = payload.result.toLowerCase();
      if (message.includes('no transactions found')) {
        return { transfers: [], upstream: payload, timestamp: Date.now() };
      }
    }

    if (payload.status !== '1' && payload.message && !String(payload.message).toLowerCase().includes('no transactions')) {
      const error = new Error(payload.result || payload.message || 'Upstream error');
      error.code = 'UPSTREAM_ERROR';
      error.upstreamResponse = payload;
      throw error;
    }

    return {
      transfers: sanitizeInternalTransfers(result, chain),
      upstream: payload,
      timestamp: Date.now(),
    };
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `internal_${chain.id}_rate_limit` });
    }
    throw error;
  }
};

const resolveInternalPageData = async ({
  chain,
  page,
  pageSize,
  sort,
  address,
  forceRefresh = false,
}) => {
  const cacheKey = buildInternalPageCacheKey({
    chainId: chain.id,
    page,
    pageSize,
    sort,
    address,
  });

  if (forceRefresh) {
    internalPageCache.delete(cacheKey);
    internalPagePromises.delete(cacheKey);
  }

  const cached = forceRefresh ? null : getCachedInternalPage(cacheKey);
  if (cached && !cached.stale && cached.payload) {
    return { ...cached.payload, stale: false, source: 'cache', cacheTimestamp: cached.timestamp };
  }

  let promise = internalPagePromises.get(cacheKey);
  if (!promise) {
    promise = fetchInternalTransfersPageFromChain({ chain, page, pageSize, sort, address })
      .then((payload) => {
        const wrapped = { ...payload, page, pageSize, sort };
        setCachedInternalPage(cacheKey, wrapped);
        return wrapped;
      })
      .finally(() => {
        internalPagePromises.delete(cacheKey);
      });
    internalPagePromises.set(cacheKey, promise);
  }

  try {
    const fresh = await promise;
    return { ...fresh, stale: false, source: 'network', cacheTimestamp: Date.now() };
  } catch (error) {
    if (cached?.payload) {
      console.warn(`! Returning stale internal transfers for ${chain.name}: ${error.message || error}`);
      return { ...cached.payload, stale: true, source: 'stale-cache', error, cacheTimestamp: cached.timestamp };
    }
    throw error;
  }
};

const getSingleChainInternalTransfers = async ({
  chainId,
  page,
  pageSize,
  sort,
  address,
  forceRefresh = false,
}) => {
  const chain = getChainDefinition(chainId);
  if (!chain) {
    const error = new Error(`Unsupported chain requested: ${chainId}`);
    error.code = 'INVALID_CHAIN_ID';
    error.availableChains = CHAINS.map((c) => c.id);
    throw error;
  }

  const pageData = await resolveInternalPageData({
    chain,
    page,
    pageSize,
    sort,
    address,
    forceRefresh,
  });

  const totalCount = pageData.transfers.length;
  const totalPages = totalCount > 0 ? Math.ceil(totalCount / pageSize) : 1;
  const hasMore = totalCount === pageSize;

  return {
    data: pageData.transfers,
    meta: {
      page,
      pageSize,
      total: totalCount,
      totalPages,
      hasMore,
    },
    chain: { id: chain.id, name: chain.name },
    sort,
    timestamp: pageData.timestamp,
    stale: Boolean(pageData.stale),
    source: pageData.source || 'upstream',
    warnings: pageData.stale ? [{ scope: 'page', code: 'STALE_PAGE', message: 'Returned stale cached data.' }] : [],
  };
};

const getAggregatedInternalTransfers = async ({
  page,
  pageSize,
  sort,
  address,
  forceRefresh = false,
}) => {
  const etherscanChains = CHAINS.filter((c) => getProviderKeyForChain(c) !== 'cronos');

  const fetchPageSize = address ? Math.min(100, pageSize) : pageSize;

  const results = await mapWithConcurrency(
    etherscanChains,
    MAX_CONCURRENT_REQUESTS,
    async (chain) => {
      try {
        const data = await resolveInternalPageData({
          chain,
          page: 1,
          pageSize: fetchPageSize,
          sort,
          address,
          forceRefresh,
        });
        return { chain, data, error: null };
      } catch (error) {
        console.warn(`! Failed internal transfers from ${chain.name}: ${error.message || error}`);
        return { chain, data: null, error };
      }
    }
  );

  const combined = [];
  const warnings = [];

  results.forEach((result) => {
    if (result.data?.transfers) {
      combined.push(...result.data.transfers);
      if (result.data.stale) {
        warnings.push({
          scope: 'chain',
          code: 'STALE_CHAIN',
          message: `Chain ${result.chain.name} returned stale cached internal tx data.`,
        });
      }
    } else if (result.error) {
      warnings.push({
        scope: 'chain',
        code: result.error.code || 'CHAIN_FETCH_FAILED',
        message: `Failed to fetch internal tx for ${result.chain.name}: ${result.error.message || result.error}`,
      });
    }
  });

  combined.sort((a, b) => {
    const timeA = Number(a.timeStamp);
    const timeB = Number(b.timeStamp);
    return sort === 'asc' ? timeA - timeB : timeB - timeA;
  });

  const totalCount = combined.length;
  const startIndex = (page - 1) * pageSize;
  const paginated = combined.slice(startIndex, startIndex + pageSize);
  const totalPages = totalCount > 0 ? Math.ceil(totalCount / pageSize) : 1;

  return {
    data: paginated,
    meta: {
      page,
      pageSize,
      total: totalCount,
      totalPages,
      hasMore: page < totalPages,
      totalIsApproximate: true,
    },
    chain: { id: 0, name: 'All Chains' },
    sort,
    timestamp: Date.now(),
    stale: warnings.some((w) => w.code.includes('STALE')),
    source: 'aggregated',
    warnings,
  };
};

module.exports = {
  getSingleChainInternalTransfers,
  getAggregatedInternalTransfers,
};


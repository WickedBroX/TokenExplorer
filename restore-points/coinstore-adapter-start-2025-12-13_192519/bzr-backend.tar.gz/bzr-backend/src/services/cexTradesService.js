'use strict';

const { query, getDbPool } = require('../utils/db');

const normalizeExchangeId = (value) => {
  if (!value) return null;
  return String(value).trim().toLowerCase();
};

const normalizeSymbol = (value) => {
  if (!value) return null;
  const trimmed = String(value).trim();
  return trimmed.length ? trimmed : null;
};

const parseMarketEntry = (entry) => {
  const raw = String(entry || '').trim();
  if (!raw) return null;
  const [exchangeIdRaw, symbolRaw] = raw.split(':').map((v) => (v ? v.trim() : ''));
  const exchangeId = normalizeExchangeId(exchangeIdRaw);
  const symbol = normalizeSymbol(symbolRaw);
  if (!exchangeId || !symbol) return null;

  const [baseSymbol, quoteSymbol] = symbol.includes('/')
    ? symbol.split('/').map((v) => (v ? v.trim() : null))
    : [null, null];

  return {
    exchangeId,
    symbol,
    baseSymbol: baseSymbol || null,
    quoteSymbol: quoteSymbol || null,
  };
};

const bootstrapCexMarketsFromEnv = async () => {
  if (!getDbPool()) return { enabled: false, inserted: 0 };

  const raw = process.env.CEX_MARKETS;
  if (!raw) return { enabled: true, inserted: 0 };

  const entries = raw
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean);

  if (!entries.length) return { enabled: true, inserted: 0 };

  let inserted = 0;
  for (const entry of entries) {
    const parsed = parseMarketEntry(entry);
    if (!parsed) continue;
    const res = await query(
      `
      INSERT INTO cex_markets (exchange_id, symbol, base_symbol, quote_symbol, active)
      VALUES ($1, $2, $3, $4, TRUE)
      ON CONFLICT (exchange_id, symbol) DO UPDATE
      SET active = TRUE,
          base_symbol = COALESCE(cex_markets.base_symbol, EXCLUDED.base_symbol),
          quote_symbol = COALESCE(cex_markets.quote_symbol, EXCLUDED.quote_symbol),
          updated_at = NOW()
      `,
      [parsed.exchangeId, parsed.symbol, parsed.baseSymbol, parsed.quoteSymbol]
    );
    inserted += res.rowCount || 0;
  }

  return { enabled: true, inserted };
};

const listCexMarkets = async ({ activeOnly = true } = {}) => {
  const pool = getDbPool();
  if (!pool) return [];
  const where = activeOnly ? 'WHERE active = TRUE' : '';
  const res = await query(
    `
    SELECT
      exchange_id as "exchangeId",
      symbol,
      base_symbol as "baseSymbol",
      quote_symbol as "quoteSymbol",
      active,
      meta,
      created_at as "createdAt",
      updated_at as "updatedAt"
    FROM cex_markets
    ${where}
    ORDER BY exchange_id, symbol
    `
  );
  return res.rows || [];
};

const fetchCexTrades = async ({
  exchangeId,
  symbol,
  page = 1,
  pageSize = 25,
  sort = 'desc',
} = {}) => {
  const pool = getDbPool();
  if (!pool) {
    return {
      data: [],
      pagination: { page: 1, pageSize, resultCount: 0, total: 0, hasMore: false },
      timestamp: Date.now(),
      enabled: false,
      message: 'Database not configured',
    };
  }

  const normalizedPage = Math.max(1, Number(page) || 1);
  const normalizedPageSize = Math.min(200, Math.max(10, Number(pageSize) || 25));
  const direction = String(sort).toLowerCase() === 'asc' ? 'ASC' : 'DESC';

  const where = [];
  const params = [];
  let idx = 1;

  const normalizedExchange = normalizeExchangeId(exchangeId);
  if (normalizedExchange) {
    where.push(`exchange_id = $${idx++}`);
    params.push(normalizedExchange);
  }

  const normalizedSymbol = normalizeSymbol(symbol);
  if (normalizedSymbol) {
    where.push(`symbol = $${idx++}`);
    params.push(normalizedSymbol);
  }

  const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const offset = (normalizedPage - 1) * normalizedPageSize;

  const countRes = await query(
    `SELECT COUNT(*)::bigint AS total FROM cex_trades ${whereClause}`,
    params
  );
  const total = Number(countRes.rows?.[0]?.total || 0);

  const dataRes = await query(
    `
    SELECT
      exchange_id as "exchangeId",
      symbol,
      trade_id as "tradeId",
      FLOOR(EXTRACT(EPOCH FROM time_stamp))::double precision as "timeStamp",
      side,
      price::double precision as "price",
      amount_base::double precision as "amountBase",
      cost_quote::double precision as "costQuote",
      fee_quote::double precision as "feeQuote",
      payload
    FROM cex_trades
    ${whereClause}
    ORDER BY time_stamp ${direction}, trade_id ${direction}
    LIMIT $${idx++} OFFSET $${idx++}
    `,
    [...params, normalizedPageSize, offset]
  );

  const rows = dataRes.rows || [];
  const hasMore = offset + rows.length < total;

  return {
    enabled: true,
    data: rows,
    pagination: {
      page: normalizedPage,
      pageSize: normalizedPageSize,
      resultCount: rows.length,
      total,
      hasMore,
    },
    timestamp: Date.now(),
  };
};

const fetchCexDailyVolume = async ({
  exchangeId,
  symbol,
  days = 30,
} = {}) => {
  const pool = getDbPool();
  if (!pool) {
    return {
      enabled: false,
      totals: { volumeQuote24h: null, trades24h: null },
      series: [],
      timestamp: Date.now(),
      message: 'Database not configured',
    };
  }

  const normalizedDays = Math.min(365, Math.max(1, Number(days) || 30));

  const where = [];
  const params = [];
  let idx = 1;

  const normalizedExchange = normalizeExchangeId(exchangeId);
  if (normalizedExchange) {
    where.push(`exchange_id = $${idx++}`);
    params.push(normalizedExchange);
  }

  const normalizedSymbol = normalizeSymbol(symbol);
  if (normalizedSymbol) {
    where.push(`symbol = $${idx++}`);
    params.push(normalizedSymbol);
  }

  const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const totalsRes = await query(
    `
    SELECT
      COALESCE(SUM(cost_quote), 0)::double precision as "volumeQuote24h",
      COUNT(*)::int as "trades24h"
    FROM cex_trades
    ${whereClause}
    ${whereClause ? 'AND' : 'WHERE'} time_stamp >= NOW() - INTERVAL '24 hours'
    `,
    params
  );

  const seriesRes = await query(
    `
    SELECT
      day::text as day,
      exchange_id as "exchangeId",
      symbol,
      volume_base::double precision as "volumeBase",
      volume_quote::double precision as "volumeQuote",
      open::double precision as "open",
      high::double precision as "high",
      low::double precision as "low",
      close::double precision as "close",
      trade_count as "tradeCount"
    FROM cex_daily_stats
    ${whereClause}
    ${whereClause ? 'AND' : 'WHERE'} day >= (CURRENT_DATE - $${idx++}::int)
    ORDER BY day ASC, exchange_id ASC
    `,
    [...params, normalizedDays]
  );

  return {
    enabled: true,
    totals: totalsRes.rows?.[0] || { volumeQuote24h: 0, trades24h: 0 },
    series: seriesRes.rows || [],
    timestamp: Date.now(),
  };
};

module.exports = {
  bootstrapCexMarketsFromEnv,
  listCexMarkets,
  fetchCexTrades,
  fetchCexDailyVolume,
};


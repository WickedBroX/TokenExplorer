'use strict';

const axios = require('axios');
const { getAthAtlFromCoingecko } = require('./coingeckoAthService');

const CMC_CACHE_TTL_MS = Number(process.env.CMC_CACHE_TTL_MS || 30_000);
const DEFAULT_MAX_SUPPLY = Number(process.env.BZR_TOKEN_MAX_SUPPLY || 555_555_555);
const DEFAULT_TOTAL_SUPPLY = Number(process.env.BZR_TOKEN_TOTAL_SUPPLY || DEFAULT_MAX_SUPPLY);
const DEFAULT_CIRC_SUPPLY = Number(process.env.BZR_TOKEN_CIRC_SUPPLY || DEFAULT_TOTAL_SUPPLY);
const BUNDLE_BASE_URL = process.env.BZR_BUNDLE_BASE_URL || 'https://bzr-bundle.info-exchangepro3617.workers.dev';
const BUNDLE_TIMEOUT_MS = Number(process.env.BZR_BUNDLE_TIMEOUT_MS || 7_500);

let cachedPayload = null;
let cachedAt = 0;

const toNumber = (value) => {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
};

const fetchBundleSupply = async () => {
  if (!BUNDLE_BASE_URL) return null;
  const endpoints = ['maxcoins', 'totalcoins', 'circulating'];
  const results = await Promise.all(
    endpoints.map((endpoint) =>
      axios
        .get(`${BUNDLE_BASE_URL}/${endpoint}`, { timeout: BUNDLE_TIMEOUT_MS })
        .then((resp) => toNumber(resp?.data))
        .catch((err) => {
          console.warn(`! Bundle supply fetch failed for ${endpoint}:`, err.message);
          return null;
        })
    )
  );

  const [maxSupply, totalSupply, circulatingSupply] = results;
  if ([maxSupply, totalSupply, circulatingSupply].every((v) => v === null)) {
    return null;
  }

  return { maxSupply, totalSupply, circulatingSupply };
};

const computeDerived = (payload) => {
  if (!payload) return payload;

  const price = Number(payload.priceUsd) || null;
  const supCandidates = [
    payload.circulatingSupply,
    payload.selfReportedCirculatingSupply,
    payload.totalSupply,
    payload.maxSupply,
  ].filter((v) => Number.isFinite(v) && v > 0);

  if (!payload.marketCapUsd && price && supCandidates.length) {
    payload.marketCapUsd = price * supCandidates[0];
    payload.warnings = [...(payload.warnings || []), 'Market cap derived from available supply'];
  }

  if (!payload.fdvUsd && price && payload.maxSupply) {
    payload.fdvUsd = price * payload.maxSupply;
    payload.warnings = [...(payload.warnings || []), 'FDV derived from max supply'];
  }

  if (!payload.volMarketCapRatio && payload.volume24hUsd && payload.marketCapUsd) {
    payload.volMarketCapRatio = payload.marketCapUsd > 0 ? payload.volume24hUsd / payload.marketCapUsd : null;
  }

  return payload;
};

const applyBundleSupply = async (payload) => {
  if (!payload) return payload;
  try {
    const bundle = await fetchBundleSupply();
    if (!bundle) return payload;

    const merged = { ...payload };
    let changed = false;

    if (bundle.maxSupply !== null) {
      merged.maxSupply = bundle.maxSupply;
      changed = true;
    }
    if (bundle.totalSupply !== null) {
      merged.totalSupply = bundle.totalSupply;
      changed = true;
    }
    if (bundle.circulatingSupply !== null) {
      merged.circulatingSupply = bundle.circulatingSupply;
      merged.selfReportedCirculatingSupply = bundle.circulatingSupply;
      changed = true;
    }

    if (changed) {
      merged.warnings = [...(merged.warnings || []), 'Supply values refreshed from multichain bundle API'];
      return computeDerived(merged);
    }

    return merged;
  } catch (err) {
    console.warn('! Failed to apply bundle supply:', err.message);
    return payload;
  }
};

const normalizeCmcPayload = (entry) => {
  if (!entry) return null;
  const quote = entry.quote?.USD || {};
  const marketCap = Number(quote.market_cap) || null;
  const volume24h = Number(quote.volume_24h) || null;
  const fdv = Number(quote.fully_diluted_market_cap) || null;
  const volumeChange24h = Number(quote.volume_change_24h);
   const priceChange24h = Number(quote.percent_change_24h);
  const low24h = Number(quote.low_24h);
  const high24h = Number(quote.high_24h);
  const volMcapRatio =
    marketCap && marketCap > 0 && volume24h
      ? volume24h / marketCap
      : null;

  return {
    source: 'coinmarketcap',
    priceUsd: Number(quote.price) || null,
    marketCapUsd: marketCap,
    fdvUsd: fdv,
    volume24hUsd: volume24h,
    volumeChange24hPercent: Number.isFinite(volumeChange24h) ? volumeChange24h : null,
    priceChange24hPercent: Number.isFinite(priceChange24h) ? priceChange24h : null,
    low24hUsd: Number.isFinite(low24h) ? low24h : null,
    high24hUsd: Number.isFinite(high24h) ? high24h : null,
    volMarketCapRatio: volMcapRatio,
    circulatingSupply: Number(entry.circulating_supply) || null,
    selfReportedCirculatingSupply: Number(entry.self_reported_circulating_supply) || null,
    totalSupply: Number(entry.total_supply) || null,
    maxSupply: Number(entry.max_supply) || null,
    stale: false,
    warnings: [],
  };
};

// Fallback to provided key if env is missing (user-supplied)
const getCmcKey = () => process.env.COINMARKETCAP_API_KEY || '43a86b963ef04d4b82425587670bb667';
const getCmcId = () => process.env.COINMARKETCAP_ID || '';
const getCmcSymbol = () => process.env.COINMARKETCAP_SYMBOL || 'BZR';

const fetchFromCmc = async () => {
  const apiKey = getCmcKey();
  if (!apiKey) {
    const err = new Error('COINMARKETCAP_API_KEY is missing');
    err.code = 'NO_CMC_KEY';
    throw err;
  }

  const id = getCmcId();
  const symbol = getCmcSymbol();
  const params = { convert: 'USD' };
  if (id) {
    params.id = id;
  } else {
    params.symbol = symbol;
  }

  const response = await axios.get('https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest', {
    params,
    headers: {
      'X-CMC_PRO_API_KEY': apiKey,
    },
    timeout: Number(process.env.CMC_TIMEOUT_MS || 10_000),
  });

  const data = response?.data?.data;
  if (!data || typeof data !== 'object') {
    throw new Error('CMC response missing data');
  }

  const firstEntry = id ? data[id] : Object.values(data)[0];
  const normalized = computeDerived(normalizeCmcPayload(firstEntry));
  const withBundle = await applyBundleSupply(normalized);
  if (!normalized) {
    throw new Error('CMC response could not be normalized');
  }

  cachedPayload = withBundle;
  cachedAt = Date.now();
  return withBundle;
};

const fallbackPayload = () => {
  const warning = 'CMC unavailable; using fallback supply and price-derived metrics';
  return {
    source: 'fallback',
    priceUsd: null,
    marketCapUsd: null,
    fdvUsd: null,
    volume24hUsd: null,
    volumeChange24hPercent: null,
    priceChange24hPercent: null,
    low24hUsd: null,
    high24hUsd: null,
    volMarketCapRatio: null,
    circulatingSupply: DEFAULT_CIRC_SUPPLY,
    selfReportedCirculatingSupply: null,
    totalSupply: DEFAULT_TOTAL_SUPPLY,
    maxSupply: DEFAULT_MAX_SUPPLY,
    athUsd: null,
    athDate: null,
    athChangePercent: null,
    atlUsd: null,
    atlDate: null,
    atlChangePercent: null,
    stale: true,
    warnings: [warning],
  };
};

const getMarketOverview = async () => {
  const now = Date.now();
  const isCached = cachedPayload && now - cachedAt < CMC_CACHE_TTL_MS;
  if (isCached) {
    return applyBundleSupply(cachedPayload);
  }

  try {
    const base = await fetchFromCmc();

    try {
      const athAtl = await getAthAtlFromCoingecko();
      const merged = { ...base };
      if (athAtl) {
        merged.athUsd = athAtl.athUsd ?? merged.athUsd;
        merged.atlUsd = athAtl.atlUsd ?? merged.atlUsd;
        merged.athDate = athAtl.athDate ?? merged.athDate;
        merged.atlDate = athAtl.atlDate ?? merged.atlDate;
        merged.athChangePercent = athAtl.athChangePercent ?? merged.athChangePercent;
        merged.atlChangePercent = athAtl.atlChangePercent ?? merged.atlChangePercent;
        if (athAtl.low24hUsd !== undefined) merged.low24hUsd = athAtl.low24hUsd;
        if (athAtl.high24hUsd !== undefined) merged.high24hUsd = athAtl.high24hUsd;
        merged.warnings = base.warnings || [];
      }
      cachedPayload = merged;
      cachedPayload = await applyBundleSupply(cachedPayload);
      cachedAt = Date.now();
      return cachedPayload;
    } catch (error) {
      const warnings = [...(base.warnings || []), 'ATH/ATL unavailable from CoinGecko'];
      cachedPayload = await applyBundleSupply({ ...base, warnings });
      cachedAt = Date.now();
      return cachedPayload;
    }
  } catch (error) {
    if (cachedPayload) {
      return { ...cachedPayload, stale: true, warnings: [...(cachedPayload.warnings || []), 'CMC fetch failed; returning cached data'] };
    }
    return applyBundleSupply(fallbackPayload());
  }
};

module.exports = {
  getMarketOverview,
};

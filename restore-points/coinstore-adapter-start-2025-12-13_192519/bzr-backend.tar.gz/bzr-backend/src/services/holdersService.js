const axios = require('axios');
const {
  CHAINS,
  getChainDefinition,
  getProviderConfigForChain,
  getProviderKeyForChain,
} = require('../config/chains');
const { getNextApiKey, markApiKeyAsFailed, shouldBackoffApiKey } = require('../utils/apiUtils');
const { getTokenAddress } = require('./configService');
const { query } = require('../utils/db');

const BUNDLE_BASE_URL = process.env.BZR_BUNDLE_BASE_URL || 'https://bzr-bundle.info-exchangepro3617.workers.dev';
const BUNDLE_TIMEOUT_MS = Number(process.env.BZR_BUNDLE_TIMEOUT_MS || 7_500);
const HOLDER_COUNT_REFRESH_MS = Number(process.env.HOLDER_COUNT_REFRESH_MS || 6 * 60 * 60 * 1000); // 6h
const HOLDER_COUNT_MAX_PAGES = Number(process.env.HOLDER_COUNT_MAX_PAGES || 2000); // safety cap
const HOLDERS_CACHE_TTL_MS = Number(process.env.HOLDERS_CACHE_TTL_MS || 3 * 60 * 1000); // 3 minutes
const HOLDERS_WARM_ENABLED = process.env.HOLDERS_WARM_ENABLED !== '0';
const HOLDERS_WARM_INTERVAL_MS = Number(process.env.HOLDERS_WARM_INTERVAL_MS || 5 * 60 * 1000); // 5 minutes
const HOLDERS_WARM_PAGE_SIZE = Number(process.env.HOLDERS_WARM_PAGE_SIZE || 50);
const SNAPSHOT_REFRESH_ENABLED = process.env.HOLDERS_SNAPSHOT_REFRESH_ENABLED !== '0';
const SNAPSHOT_REFRESH_INTERVAL_MS = Number(process.env.HOLDERS_SNAPSHOT_REFRESH_INTERVAL_MS || 15 * 60 * 1000); // 15 minutes
const SNAPSHOT_REFRESH_PAGE_SIZE = Number(process.env.HOLDERS_SNAPSHOT_REFRESH_PAGE_SIZE || 200);
const SNAPSHOT_REFRESH_MAX_PAGES = Number(process.env.HOLDERS_SNAPSHOT_REFRESH_MAX_PAGES || 100); // up to 20k holders at pageSize 200
const SNAPSHOT_REFRESH_DELAY_MS = Number(process.env.HOLDERS_SNAPSHOT_REFRESH_DELAY_MS || 2000); // delay between calls to reduce rate limits

const CHAIN_BUNDLE_SLUG = {
  1: 'eth',
  10: 'op',
  25: 'cronos',
  56: 'bsc',
  137: 'pol',
  324: 'zksync',
  5000: 'mantle',
  42161: 'arb',
  43114: 'avax',
  8453: 'base',
};

const toNumber = (value) => {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
};

const holderCountState = new Map(); // chainId -> { inProgress, updatedAt, lastError }
const holdersCache = new Map(); // key -> { data, timestamp }
const snapshotRefreshState = { inProgress: false, lastRun: 0 };

const cacheKey = (chainId, page, pageSize, search) =>
  `${chainId}-${page}-${pageSize}-${search ? search.toLowerCase() : 'all'}`;

// Insert/update holders into snapshot table
const upsertHoldersSnapshot = async (chainId, holders) => {
  if (!Array.isArray(holders) || holders.length === 0) return;
  const values = [];
  const params = [];
  holders.forEach((holder, idx) => {
    const qty = parseQuantity(holder.TokenHolderQuantity || '0');
    const address = holder.TokenHolderAddress;
    if (!address || !Number.isFinite(qty)) return;
    // params: chainId, address, balance
    params.push(chainId, address, qty);
    values.push(`($${params.length - 2}, $${params.length - 1}, $${params.length}, NOW())`);
  });
  if (!values.length) return;
  const sql = `
    INSERT INTO holders_snapshot (chain_id, address, balance, last_seen)
    VALUES ${values.join(', ')}
    ON CONFLICT (chain_id, address)
    DO UPDATE SET balance = EXCLUDED.balance, last_seen = NOW()
  `;
  await query(sql, params);
};

const getSnapshotHolders = async ({ chainId, page = 1, pageSize = 50, search }) => {
  const offset = (page - 1) * pageSize;
  const searchClause = search ? 'AND address ILIKE $3' : '';
  const params = search ? [chainId, pageSize, `%${search}%`, offset] : [chainId, pageSize, offset];

  const rows = (
    await query(
      `
      SELECT address, balance, last_seen
      FROM holders_snapshot
      WHERE chain_id = $1
      ${searchClause}
      ORDER BY balance DESC
      LIMIT $2 OFFSET $${search ? 4 : 3}
    `,
      params
    )
  ).rows;

  const totalResult = await query(
    `
      SELECT COUNT(*) AS count
      FROM holders_snapshot
      WHERE chain_id = $1
      ${searchClause}
    `,
    search ? [chainId, `%${search}%`] : [chainId]
  );
  const total = Number(totalResult.rows[0]?.count || 0);

  return { rows, total };
};

const getSnapshotTopHolders = async ({ chainId, limit = 200 }) => {
  const rows = (
    await query(
      `
        SELECT address, balance, last_seen
        FROM holders_snapshot
        WHERE chain_id = $1
        ORDER BY balance DESC
        LIMIT $2
      `,
      [chainId, limit]
    )
  ).rows;
  return rows;
};

const getSnapshotPage = async ({ chainId, page = 1, pageSize = 50, search }) => {
  const offset = (page - 1) * pageSize;
  const whereParts = ['chain_id = $1'];
  const paramsRows = [chainId, pageSize, offset];
  const paramsCount = [chainId];

  if (search) {
    whereParts.push('address ILIKE $4');
    paramsRows.push(`%${search}%`);
    paramsCount.push(`%${search}%`);
  }

  const where = `WHERE ${whereParts.join(' AND ')}`;

  const rows = (
    await query(
      `
        SELECT address, balance, last_seen
        FROM holders_snapshot
        ${where}
        ORDER BY balance DESC
        LIMIT $2 OFFSET $3
      `,
      paramsRows
    )
  ).rows;

  const totalResult = await query(
    `
      SELECT COUNT(*) AS count, MAX(last_seen) AS last_seen
      FROM holders_snapshot
      ${where}
    `,
    paramsCount
  );

  const total = Number(totalResult.rows[0]?.count || 0);
  const lastSeen = totalResult.rows[0]?.last_seen || null;

  return { rows, total, lastSeen };
};

const getAggregatedSnapshot = async ({ page = 1, pageSize = 50, search }) => {
  const offset = (page - 1) * pageSize;
  const searchClause = search ? 'WHERE address ILIKE $1' : '';
  const params = search ? [`%${search}%`, pageSize, offset] : [pageSize, offset];

  const rows = (
    await query(
      `
        SELECT address, balance, chain_id, last_seen
        FROM holders_snapshot
        ${searchClause}
        ORDER BY balance DESC
        LIMIT $${search ? 2 : 1} OFFSET $${search ? 3 : 2}
      `,
      params
    )
  ).rows;

  const totalResult = await query(
    `
      SELECT COUNT(*) AS count
      FROM holders_snapshot
      ${searchClause}
    `,
    search ? [`%${search}%`] : []
  );
  const total = Number(totalResult.rows[0]?.count || 0);

  return { rows, total };
};

// Normalize token quantities that may use mixed thousands/decimal separators.
const parseQuantity = (value) => {
  if (value === null || value === undefined) return 0;
  const raw = String(value).trim();
  if (!raw) return 0;

  // If both '.' and ',' appear, assume '.' is thousands and ',' is decimal.
  if (raw.includes('.') && raw.includes(',')) {
    const normalized = raw.replace(/\./g, '').replace(',', '.');
    const num = parseFloat(normalized);
    return Number.isFinite(num) ? num : 0;
  }

  // Otherwise strip commas as thousand separators.
  const num = parseFloat(raw.replace(/,/g, ''));
  return Number.isFinite(num) ? num : 0;
};

const getCachedHolders = (chainId, page, pageSize, search) => {
  const key = cacheKey(chainId, page, pageSize, search);
  const entry = holdersCache.get(key);
  if (!entry) return null;
  const isFresh = Date.now() - entry.timestamp < HOLDERS_CACHE_TTL_MS;
  if (!isFresh) {
    holdersCache.delete(key);
    return null;
  }
  return entry.data;
};

const setCachedHolders = (chainId, page, pageSize, value, search) => {
  const key = cacheKey(chainId, page, pageSize, search);
  holdersCache.set(key, { data: value, timestamp: Date.now() });
};

const warmChains = [1, 25, 56, 137, 42161, 8453]; // ETH, Cronos, BSC, Polygon, Arbitrum, Base

const warmHoldersCache = () => {
  if (!HOLDERS_WARM_ENABLED) return;
  warmChains.forEach((chainId) => {
    fetchHolders({ chainId, page: 1, pageSize: HOLDERS_WARM_PAGE_SIZE }).catch((err) => {
      console.warn(`! Warm cache holders failed for chain ${chainId}:`, err.message);
    });
  });
};

if (HOLDERS_WARM_ENABLED) {
  setInterval(warmHoldersCache, HOLDERS_WARM_INTERVAL_MS).unref();
  // Initial warm shortly after boot
  setTimeout(warmHoldersCache, 2_000).unref();
}

const refreshSnapshots = async () => {
  if (!SNAPSHOT_REFRESH_ENABLED) return;
  if (snapshotRefreshState.inProgress) return;
  snapshotRefreshState.inProgress = true;
  snapshotRefreshState.lastRun = Date.now();

  const tokenAddress = getTokenAddress();
  const supportedChains = CHAINS;

  // Sweep multiple pages per chain to capture full holder set (bounded by SNAPSHOT_REFRESH_MAX_PAGES)
  for (const chain of supportedChains) {
    let page = 1;
    try {
      while (page <= SNAPSHOT_REFRESH_MAX_PAGES) {
        const result = await fetchHolders({
          chainId: chain.id,
          page,
          pageSize: SNAPSHOT_REFRESH_PAGE_SIZE,
          forceLive: true, // bypass snapshot/cache to refresh it
        });
        const count = result?.data?.length || 0;
        console.log(`Snapshot refresh ${chain.name} page ${page} => ${count}`);
        if (count < SNAPSHOT_REFRESH_PAGE_SIZE) break;
        page += 1;
        if (SNAPSHOT_REFRESH_DELAY_MS > 0) {
          await new Promise((res) => setTimeout(res, SNAPSHOT_REFRESH_DELAY_MS));
        }
      }
    } catch (err) {
      console.warn(`! Snapshot refresh failed for ${chain.name} on page ${page}:`, err.message);
    }
    if (SNAPSHOT_REFRESH_DELAY_MS > 0) {
      await new Promise((res) => setTimeout(res, SNAPSHOT_REFRESH_DELAY_MS));
    }
  }

  // Refresh aggregated materialized view (best-effort)
  try {
    await query('SELECT refresh_holders_snapshot_top_all()');
  } catch (err) {
    console.warn('! Failed to refresh holders_snapshot_top_all:', err.message);
  }

  snapshotRefreshState.inProgress = false;
};

if (SNAPSHOT_REFRESH_ENABLED) {
  setInterval(refreshSnapshots, SNAPSHOT_REFRESH_INTERVAL_MS).unref();
  setTimeout(refreshSnapshots, 5_000).unref();
}

const fetchChainSupply = async (chainId) => {
  const slug = CHAIN_BUNDLE_SLUG[chainId];
  if (!slug || !BUNDLE_BASE_URL) return null;

  try {
    const resp = await axios.get(`${BUNDLE_BASE_URL}/totalcoins`, {
      params: { chains: slug },
      timeout: BUNDLE_TIMEOUT_MS,
    });
    return toNumber(resp?.data);
  } catch (err) {
    console.warn(`! Failed to fetch chain supply from bundle for chain ${chainId}:`, err.message);
    return null;
  }
};

const getStoredHolderCount = async (chainId) => {
  try {
    const result = await query('SELECT holder_count, updated_at FROM holder_counts WHERE chain_id = $1', [chainId]);
    if (result.rows.length === 0) return null;
    return {
      count: Number(result.rows[0].holder_count),
      updatedAt: result.rows[0].updated_at,
    };
  } catch (err) {
    console.warn('! Failed to read holder count from DB:', err.message);
    return null;
  }
};

const upsertHolderCount = async (chainId, count, source = 'tokenholderlist') => {
  try {
    await query(
      `INSERT INTO holder_counts (chain_id, holder_count, updated_at, source)
       VALUES ($1, $2, NOW(), $3)
       ON CONFLICT (chain_id) DO UPDATE
         SET holder_count = EXCLUDED.holder_count,
             updated_at = NOW(),
             source = EXCLUDED.source`,
      [chainId, count, source]
    );
  } catch (err) {
    console.warn('! Failed to upsert holder count:', err.message);
  }
};

const computeHolderCount = async (chain, tokenAddress) => {
  const provider = getProviderConfigForChain(chain, { requireApiKey: false });
  const apiKey = provider.key === 'etherscan' ? getNextApiKey() : provider.apiKey;
  if (provider.key === 'etherscan' && !apiKey) {
    throw new Error('Etherscan API key unavailable');
  }

  let page = 1;
  const pageSize = 200;
  let total = 0;

  while (page <= HOLDER_COUNT_MAX_PAGES) {
    const params = {
      module: 'token',
      action: provider.blockscoutTokenHolders ? 'getTokenHolders' : 'tokenholderlist',
      contractaddress: tokenAddress,
      page,
      offset: pageSize,
    };
    if (provider.requiresChainId) {
      params.chainid = chain.id;
    }
    if (apiKey) {
      params.apikey = apiKey;
    }

    const response = await axios.get(provider.baseUrl, {
      params,
      timeout: 30000,
    });

    if (response.data.status !== '1') {
      throw new Error(response.data.message || 'Failed to fetch holders from upstream');
    }

    const rawHolders = Array.isArray(response.data.result) ? response.data.result : [];
    const normalized = rawHolders.map((holder) => ({
      TokenHolderAddress: holder.TokenHolderAddress || holder.address,
      TokenHolderQuantity: holder.TokenHolderQuantity || holder.value || holder.balance,
    }));
    const filtered = rawHolders.filter((holder) => {
      const raw = parseFloat((holder.TokenHolderQuantity || holder.value || holder.balance || '0').toString());
      return Number.isFinite(raw) && raw > 0;
    });

    total += filtered.length;

    if (rawHolders.length < pageSize) {
      break;
    }
    page += 1;
  }

  return total;
};

const scheduleHolderCountRefresh = (chain, tokenAddress) => {
  const state = holderCountState.get(chain.id) || {};
  const now = Date.now();
  if (state.inProgress) return;
  if (state.updatedAt && now - state.updatedAt < HOLDER_COUNT_REFRESH_MS) return;

  holderCountState.set(chain.id, { ...state, inProgress: true });
  computeHolderCount(chain, tokenAddress)
    .then((count) => upsertHolderCount(chain.id, count))
    .catch((err) => console.warn(`! Holder count refresh failed for chain ${chain.name}:`, err.message))
    .finally(() => {
      holderCountState.set(chain.id, { inProgress: false, updatedAt: Date.now() });
    });
};

// forceLive: bypass snapshot/cache and hit upstream to refresh snapshot
const fetchHolders = async ({ chainId, page = 1, pageSize = 50, search, forceLive = false }) => {
  const tokenAddress = getTokenAddress();
  if (!tokenAddress) {
    throw new Error('Token address is not configured');
  }

  const chain = getChainDefinition(chainId);
  if (!chain) {
    const error = new Error('Invalid chain ID');
    error.code = 'INVALID_CHAIN_ID';
    error.availableChains = CHAINS;
    throw error;
  }

  let provider;
  let apiKey;

  try {
    // 0) Prefer snapshot for full coverage (unless forcing live)
    if (!forceLive) {
      const snapshot = await getSnapshotPage({ chainId, page, pageSize, search });
      if (snapshot.rows.length > 0) {
        const chainSupply = await fetchChainSupply(chain.id);
        const responsePayload = {
          data: snapshot.rows.map((row) => ({
            TokenHolderAddress: row.address,
            TokenHolderQuantity: String(row.balance),
            chainId: chain.id,
            chainName: chain.name,
          })),
          chain: {
            id: chain.id,
            name: chain.name,
          },
          pagination: {
            page,
            pageSize,
            resultCount: snapshot.rows.length,
            totalRaw: snapshot.total,
            total: snapshot.total,
            hasMore: snapshot.total > page * pageSize,
          },
          supply: {
            totalSupply: chainSupply,
          },
          lastUpdated: snapshot.lastSeen,
          timestamp: Date.now(),
        };
        return responsePayload;
      }
    }

    // Serve from cache if fresh
    if (!forceLive) {
      const cached = getCachedHolders(chainId, page, pageSize, search);
      if (cached) {
        return cached;
      }
    }

    provider = getProviderConfigForChain(chain, { requireApiKey: false });
    apiKey = provider.key === 'etherscan' ? getNextApiKey() : provider.apiKey;
    if (provider.key === 'etherscan' && !apiKey) {
      throw new Error('Etherscan API key unavailable');
    }

    const params = {
      module: 'token',
      action: provider.blockscoutTokenHolders ? 'getTokenHolders' : 'tokenholderlist',
      contractaddress: tokenAddress,
      page,
      offset: pageSize,
    };
    if (provider.requiresChainId) {
      params.chainid = chain.id;
    }
    if (apiKey) {
      params.apikey = apiKey;
    }

    const response = await axios.get(provider.baseUrl, {
      params,
      timeout: 30000,
    });

    if (response.data.status !== '1') {
      console.error(`X holders upstream error for ${chain.name}:`, response.data.message);
      const error = new Error(response.data.message || 'Failed to fetch holders from upstream');
      error.code = 'UPSTREAM_ERROR';
      error.upstreamResponse = response.data;
      throw error;
    }

    const rawHolders = Array.isArray(response.data.result) ? response.data.result : [];
    const normalizedRaw = rawHolders.map((holder) => ({
      TokenHolderAddress: holder.TokenHolderAddress || holder.address,
      TokenHolderQuantity: holder.TokenHolderQuantity || holder.value || holder.balance,
    }));

    // Keep all non-zero holders (no dust filtering) so tiny balances are visible.
    let filteredHolders = normalizedRaw
      .filter((holder) => {
        const raw = parseQuantity(holder.TokenHolderQuantity || '0');
        return Number.isFinite(raw) && raw > 0;
      })
      .sort((a, b) => {
        const balA = parseQuantity(a.TokenHolderQuantity || '0');
        const balB = parseQuantity(b.TokenHolderQuantity || '0');
        return balB - balA;
      });

    if (search) {
      const needle = search.toLowerCase();
      filteredHolders = filteredHolders.filter((h) =>
        (h.TokenHolderAddress || '').toLowerCase().includes(needle)
      );
    }

    console.log(`-> Fetched ${rawHolders.length} holders for ${chain.name} (page ${page}). Kept ${filteredHolders.length} non-zero holders.`);
    
    // Inject chain info into each holder for consistency with aggregated results
    const holdersWithChainInfo = filteredHolders.map(holder => ({
      ...holder,
      chainId: chain.id,
      chainName: chain.name,
    }));

    const chainSupply = await fetchChainSupply(chain.id);
    const storedCount = await getStoredHolderCount(chain.id);
    const hasMore = rawHolders.length === pageSize && (!search || filteredHolders.length >= pageSize);

    // Trigger async refresh of holder count if stale (non-blocking)
    scheduleHolderCountRefresh(chain, tokenAddress);

    const responsePayload = {
      data: holdersWithChainInfo,
      chain: {
        id: chain.id,
        name: chain.name,
      },
      pagination: {
        page,
        pageSize,
        resultCount: filteredHolders.length,
        totalRaw: rawHolders.length,
        hasMore,
        total: storedCount?.count || null,
      },
      supply: {
        totalSupply: chainSupply,
      },
      timestamp: Date.now(),
    };

    // Snapshot to DB (best-effort)
    upsertHoldersSnapshot(chain.id, holdersWithChainInfo).catch((err) =>
      console.warn(`! Failed to upsert holders snapshot for ${chain.name}:`, err.message)
    );

    // Cache response for fast reuse
    setCachedHolders(chainId, page, pageSize, responsePayload, search);
    return responsePayload;
  } catch (error) {
    // Fallback to snapshot if available
    try {
      const snapshot = await getSnapshotHolders({ chainId, page, pageSize });
      if (snapshot.rows.length > 0) {
        const chainSupply = await fetchChainSupply(chainId);
        return {
          data: snapshot.rows.map((row) => ({
            TokenHolderAddress: row.address,
            TokenHolderQuantity: String(row.balance),
            chainId,
            chainName: getChainDefinition(chainId)?.name,
          })),
          chain: { id: chainId, name: getChainDefinition(chainId)?.name || 'Unknown' },
          pagination: {
            page,
            pageSize,
            resultCount: snapshot.rows.length,
            totalRaw: snapshot.total,
            total: snapshot.total,
            hasMore: snapshot.total > page * pageSize,
          },
          supply: { totalSupply: chainSupply },
          warning: 'Served from snapshot cache (upstream unavailable)',
          timestamp: Date.now(),
        };
      }
    } catch (snapshotErr) {
      console.warn(`! Snapshot fallback failed for chain ${chainId}:`, snapshotErr.message);
    }

    if (provider.key === 'etherscan' && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `holders_${chain.id}_rate_limit` });
    }
    console.error(`Error fetching holders for ${chain.name}:`, error.message);
    throw error;
  }
};

const fetchAggregatedHolders = async ({ page = 1, pageSize = 50, search }) => {
  // 1) Try serving from snapshot (full holder set across chains)
  try {
    const snapshot = await getAggregatedSnapshot({ page, pageSize, search });
    if (snapshot.rows.length > 0) {
      // Map chain names
      const chainNameMap = new Map(CHAINS.map((c) => [c.id, c.name]));
      // Sum supplies for percentages
  const supportedChains = CHAINS;
      const supplyResults = await Promise.all(
        supportedChains.map(async (chain) => ({
          chainId: chain.id,
          supply: await fetchChainSupply(chain.id),
        }))
      );
      const totalSupply = supplyResults
        .map((s) => (Number.isFinite(s.supply) ? Number(s.supply) : null))
        .filter((v) => v !== null)
        .reduce((acc, val) => acc + val, 0);

      return {
        data: snapshot.rows.map((row) => ({
          TokenHolderAddress: row.address,
          TokenHolderQuantity: String(row.balance),
          chainId: row.chain_id,
          chainName: chainNameMap.get(row.chain_id) || 'Unknown',
        })),
        chain: { id: 0, name: 'All Chains' },
        pagination: {
          page,
          pageSize,
          resultCount: snapshot.rows.length,
          totalRaw: snapshot.total,
          total: snapshot.total,
          hasMore: snapshot.total > page * pageSize,
        },
        supply: {
          totalSupply: Number.isFinite(totalSupply) && totalSupply > 0 ? totalSupply : null,
        },
        timestamp: Date.now(),
      };
    }
  } catch (err) {
    console.warn('! Aggregated snapshot unavailable, falling back to live fetch:', err.message);
  }

  // 2) Fallback: live fetch top holders per chain (best-effort)
  const supportedChains = CHAINS;

  console.log(`-> Fetching aggregated holders live from ${supportedChains.length} chains...`);

  // Pre-fetch per-chain supplies to sum for global percentage calculations
  const supplyResults = await Promise.all(
    supportedChains.map(async (chain) => ({
      chainId: chain.id,
      supply: await fetchChainSupply(chain.id),
    }))
  );

  // Pull stored holder counts (best-known totals)
  const storedCounts = await Promise.all(
    supportedChains.map(async (chain) => ({
      chainId: chain.id,
      stored: await getStoredHolderCount(chain.id),
    }))
  );

  const fetchPromises = supportedChains.map(chain => 
    fetchHolders({ chainId: chain.id, page: 1, pageSize: 100 })
      .then(result => ({ status: 'fulfilled', value: result.data, chainId: chain.id, chainName: chain.name }))
      .catch(async error => {
        console.warn(`! Failed to fetch holders from ${chain.name}: ${error.message}`);
        // Try snapshot fallback
        const snapshotRows = await getSnapshotTopHolders({ chainId: chain.id, limit: 200 }).catch(() => []);
        if (snapshotRows && snapshotRows.length > 0) {
          return {
            status: 'fulfilled',
            value: snapshotRows.map(row => ({
              TokenHolderAddress: row.address,
              TokenHolderQuantity: String(row.balance),
              chainId: chain.id,
              chainName: chain.name,
            })),
            chainId: chain.id,
            chainName: chain.name,
            warning: 'Served from snapshot cache (upstream unavailable)',
          };
        }
        return { status: 'rejected', reason: error };
      })
  );

  const results = await Promise.all(fetchPromises);

  let allHolders = [];
  results.forEach(result => {
    if (result.status === 'fulfilled' && Array.isArray(result.value)) {
      const holdersWithChain = result.value.map(holder => ({
        ...holder,
        chainId: result.chainId,
        chainName: result.chainName,
      }));
      allHolders = allHolders.concat(holdersWithChain);
    }
  });

  if (search) {
    const needle = search.toLowerCase();
    allHolders = allHolders.filter((h) => h.TokenHolderAddress.toLowerCase().includes(needle));
  }

  allHolders.sort((a, b) => {
    const balanceA = parseQuantity(a.TokenHolderQuantity);
    const balanceB = parseQuantity(b.TokenHolderQuantity);
    return balanceB - balanceA;
  });

  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedHolders = allHolders.slice(startIndex, endIndex);

  const totalSupply = supplyResults
    .map((s) => (Number.isFinite(s.supply) ? Number(s.supply) : null))
    .filter((v) => v !== null)
    .reduce((acc, val) => acc + val, 0);

  const totalHolderCount = storedCounts
    .map((c) => (c.stored?.count ? Number(c.stored.count) : null))
    .filter((v) => Number.isFinite(v))
    .reduce((acc, val) => acc + val, 0);

  const tokenAddress = getTokenAddress();
  supportedChains.forEach((chain) => scheduleHolderCountRefresh(chain, tokenAddress));

  return {
    data: paginatedHolders,
    chain: { id: 0, name: 'All Chains' },
    pagination: {
      page,
      pageSize,
      resultCount: paginatedHolders.length,
      totalRaw: allHolders.length,
      total: Number.isFinite(totalHolderCount) && totalHolderCount > 0 ? totalHolderCount : null,
      hasMore: allHolders.length > endIndex,
    },
    supply: {
      totalSupply: Number.isFinite(totalSupply) && totalSupply > 0 ? totalSupply : null,
    },
    timestamp: Date.now(),
  };
};

module.exports = {
  fetchHolders,
  fetchAggregatedHolders,
};

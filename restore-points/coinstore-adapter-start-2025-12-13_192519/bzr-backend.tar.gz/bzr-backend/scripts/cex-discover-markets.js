#!/usr/bin/env node
'use strict';

// Discover potential markets for a token symbol across exchanges (CCXT).
// Usage:
//   node scripts/cex-discover-markets.js --token BZR
//   CEX_EXCHANGES=bitmart,gateio,mexc,kucoin node scripts/cex-discover-markets.js

const ccxt = require('ccxt');

const getArgValue = (flag) => {
  const idx = process.argv.indexOf(flag);
  if (idx === -1) return null;
  return process.argv[idx + 1] || null;
};

const token = String(getArgValue('--token') || 'BZR').trim().toUpperCase();
const exchanges = String(process.env.CEX_EXCHANGES || 'bitmart,gateio,mexc,kucoin')
  .split(',')
  .map((v) => v.trim().toLowerCase())
  .filter(Boolean);

const preferredQuotes = new Set(['USDT', 'USDC', 'USD', 'DAI']);

const main = async () => {
  const results = [];

  for (const exchangeId of exchanges) {
    const ExchangeClass = ccxt[exchangeId];
    if (!ExchangeClass) {
      console.warn(`! CCXT does not support exchange: ${exchangeId}`);
      continue;
    }

    const exchange = new ExchangeClass({ enableRateLimit: true });
    try {
      const markets = await exchange.loadMarkets();
      const symbols = Object.keys(markets || {});
      const matches = symbols
        .filter((s) => s.includes('/'))
        .filter((s) => {
          const [base, quote] = s.split('/').map((v) => String(v || '').toUpperCase());
          return base === token && preferredQuotes.has(quote);
        })
        .sort((a, b) => a.localeCompare(b));

      if (!matches.length) {
        console.log(`${exchangeId}: no ${token}/(USDT|USDC|USD|DAI) markets found`);
        continue;
      }

      for (const symbol of matches) {
        results.push({ exchangeId, symbol });
      }
      console.log(`${exchangeId}: ${matches.join(', ')}`);
    } catch (error) {
      console.warn(`! Failed to load markets for ${exchangeId}:`, error.message || error);
    } finally {
      try {
        exchange.close?.();
      } catch {
        // ignore
      }
    }
  }

  if (!results.length) {
    console.log('\nNo preferred-quote markets found.');
    return;
  }

  const envValue = results.map((r) => `${r.exchangeId}:${r.symbol}`).join(',');
  console.log('\nSuggested .env:');
  console.log(`CEX_MARKETS=${envValue}`);
};

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

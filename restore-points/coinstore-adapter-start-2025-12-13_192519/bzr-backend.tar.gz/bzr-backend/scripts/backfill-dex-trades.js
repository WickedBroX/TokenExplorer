#!/usr/bin/env node
'use strict';

/**
 * Manual backfill for DEX trades (TokenTrade tab).
 *
 * Usage:
 *   node scripts/backfill-dex-trades.js            # all chains
 *   node scripts/backfill-dex-trades.js --chainId=137
 *
 * Requires DATABASE_URL / TRANSFERS_DATABASE_URL and valid API keys
 * (loaded from env or api_credentials table).
 */

require('dotenv').config();

const { bootstrapConfig } = require('../src/services/configService');
const dexTradesService = require('../src/services/dexTradesService');

const parseArgs = () => {
  const args = process.argv.slice(2);
  const out = {};
  for (const arg of args) {
    const [key, value] = arg.replace(/^--/, '').split('=');
    if (!key) continue;
    out[key] = value ?? true;
  }
  return out;
};

const main = async () => {
  const args = parseArgs();
  const chainId = args.chainId ? Number(args.chainId) : 0;
  const recompute = Boolean(args.recompute) || Boolean(args.recomputeOnly);
  const recomputeOnly = Boolean(args.recomputeOnly);
  const limit = args.limit ? Number(args.limit) : 10_000;

  console.log('🚀 Starting DEX trades discovery + backfill');
  if (chainId) {
    console.log(`→ Chain scope: ${chainId}`);
  } else {
    console.log('→ Chain scope: All Chains');
  }

  await bootstrapConfig();

  if (recomputeOnly) {
    console.log('🧮 Recomputing stored DEX trade USD values');
    const recomputeResult = await dexTradesService.recomputeDexTradesUsd({ chainId, limit });
    console.log('✅ Recompute complete');
    console.log(JSON.stringify(recomputeResult, null, 2));
    process.exit(0);
  }

  const result = await dexTradesService.discoverAndBackfillDexTrades({ chainId });
  let recomputeResult = null;
  if (recompute) {
    console.log('🧮 Recomputing stored DEX trade USD values');
    recomputeResult = await dexTradesService.recomputeDexTradesUsd({ chainId, limit });
  }

  console.log('✅ DEX backfill complete');
  console.log(
    JSON.stringify(
      recomputeResult ? { ...result, recompute: recomputeResult } : result,
      null,
      2
    )
  );
  process.exit(0);
};

main().catch((err) => {
  console.error('X DEX backfill failed:', err?.message || err);
  process.exit(1);
});

-- Migration: 012-create-cex-tables.sql
-- Created at: 2025-12-13
-- Description: Schema for centralized exchange (CEX) trades + daily aggregates (CCXT ingestion)

BEGIN;

CREATE TABLE IF NOT EXISTS cex_markets (
  id BIGSERIAL PRIMARY KEY,
  exchange_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  base_symbol TEXT,
  quote_symbol TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (exchange_id, symbol)
);

CREATE INDEX IF NOT EXISTS idx_cex_markets_active ON cex_markets (active);
CREATE INDEX IF NOT EXISTS idx_cex_markets_exchange ON cex_markets (exchange_id);

CREATE TABLE IF NOT EXISTS cex_trades (
  exchange_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  trade_id TEXT NOT NULL,
  time_stamp TIMESTAMPTZ NOT NULL,
  side TEXT,
  price NUMERIC,
  amount_base NUMERIC,
  cost_quote NUMERIC,
  fee_quote NUMERIC,
  payload JSONB,
  inserted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (exchange_id, symbol, trade_id)
);

CREATE INDEX IF NOT EXISTS idx_cex_trades_exchange_time ON cex_trades (exchange_id, time_stamp DESC);
CREATE INDEX IF NOT EXISTS idx_cex_trades_symbol_time ON cex_trades (symbol, time_stamp DESC);

CREATE TABLE IF NOT EXISTS cex_daily_stats (
  day DATE NOT NULL,
  exchange_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  open NUMERIC,
  high NUMERIC,
  low NUMERIC,
  close NUMERIC,
  volume_base NUMERIC,
  volume_quote NUMERIC,
  trade_count INTEGER,
  payload JSONB,
  inserted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (day, exchange_id, symbol)
);

CREATE INDEX IF NOT EXISTS idx_cex_daily_stats_day ON cex_daily_stats (day DESC);
CREATE INDEX IF NOT EXISTS idx_cex_daily_stats_exchange_day ON cex_daily_stats (exchange_id, day DESC);

CREATE TABLE IF NOT EXISTS cex_ingest_state (
  exchange_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  last_trade_ts_ms BIGINT,
  last_trade_id TEXT,
  last_ohlcv_fetch_at TIMESTAMPTZ,
  last_error TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (exchange_id, symbol)
);

COMMIT;


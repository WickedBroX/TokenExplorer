const internalTxService = require('../services/internalTxService');
const { CHAINS } = require('../config/chains');

const DEFAULT_PAGE_SIZE = 25;
const MAX_PAGE_SIZE = 100;

const normalizePageNumber = (page) => {
  const parsed = parseInt(page, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
};

const clampPageSize = (size) => {
  const parsed = parseInt(size, 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return DEFAULT_PAGE_SIZE;
  }
  return Math.min(parsed, MAX_PAGE_SIZE);
};

const getInternalTransfers = async (req, res) => {
  console.log(`[${new Date().toISOString()}] Received request for /api/internal-transfers`);

  const forceRefresh = String(req.query.force).toLowerCase() === 'true';
  const chainIdParam = req.query.chainId;
  const requestedChainId =
    chainIdParam === 'all' || chainIdParam === '0' || !chainIdParam
      ? 0
      : Number(chainIdParam);

  const requestedPage = normalizePageNumber(req.query.page || 1);
  const requestedPageSize = clampPageSize(req.query.pageSize || DEFAULT_PAGE_SIZE);
  const sortParam = typeof req.query.sort === 'string' ? req.query.sort.toLowerCase() : 'desc';
  const sort = sortParam === 'asc' ? 'asc' : 'desc';

  const address = req.query.address ? String(req.query.address).trim() : undefined;

  try {
    let result;
    if (requestedChainId === 0) {
      result = await internalTxService.getAggregatedInternalTransfers({
        forceRefresh,
        page: requestedPage,
        pageSize: requestedPageSize,
        sort,
        address,
      });
    } else {
      result = await internalTxService.getSingleChainInternalTransfers({
        forceRefresh,
        chainId: requestedChainId,
        page: requestedPage,
        pageSize: requestedPageSize,
        sort,
        address,
      });
    }

    res.json({
      ...result,
      availableChains: CHAINS.map((c) => ({ id: c.id, name: c.name })),
    });
  } catch (error) {
    if (error.code === 'INVALID_CHAIN_ID') {
      return res.status(400).json({
        message: error.message,
        chainId: requestedChainId,
        availableChains: error.availableChains,
      });
    }

    if (error.code === 'NOT_SUPPORTED') {
      return res.status(200).json({
        data: [],
        chain: { id: requestedChainId, name: error.chainName || 'Unsupported' },
        meta: { page: requestedPage, pageSize: requestedPageSize, total: 0, totalPages: 1, hasMore: false },
        warning: error.message,
        timestamp: Date.now(),
        availableChains: CHAINS.map((c) => ({ id: c.id, name: c.name })),
      });
    }

    console.error('Error handling /api/internal-transfers request:', error.message || error);
    res.status(500).json({
      message: 'Failed to fetch internal transfers',
      error: error.message || String(error),
    });
  }
};

module.exports = {
  getInternalTransfers,
};


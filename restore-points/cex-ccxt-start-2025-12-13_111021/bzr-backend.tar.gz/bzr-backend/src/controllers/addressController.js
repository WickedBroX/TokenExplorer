const addressService = require('../services/addressService');

const isValidAddress = (addr) => /^0x[a-fA-F0-9]{40}$/.test(addr);

const getAddressDetails = async (req, res) => {
  const address = String(req.params.address || '').trim();
  if (!isValidAddress(address)) {
    return res.status(400).json({ message: 'Invalid address', address });
  }

  try {
    const data = await addressService.getAddressDetails({ address });
    res.json(data);
  } catch (error) {
    console.error('Error handling /api/address/:address request:', error.message || error);
    res.status(500).json({
      message: 'Failed to fetch address details',
      error: error.message || String(error),
    });
  }
};

module.exports = { getAddressDetails };


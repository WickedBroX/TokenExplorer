const holdersService = require('../services/holdersService');

const getHolders = async (req, res) => {
  console.log(`[${new Date().toISOString()}] Received request for /api/holders`);
  
  const requestedChainId = Number(req.query.chainId || 1); // Default to Ethereum
  const page = Math.max(1, Number(req.query.page || 1));
  // Allow larger pages so tiny balances surface; still clamp to protect upstream.
  const pageSize = Math.min(500, Math.max(10, Number(req.query.pageSize || 50))); // 10-500, default 50
  const search = (req.query.search || '').toString().trim();

  try {
    let result;
    if (requestedChainId === 0) {
      result = await holdersService.fetchAggregatedHolders({
        page,
        pageSize,
        search: search || undefined,
      });
    } else {
      result = await holdersService.fetchHolders({
        chainId: requestedChainId,
        page,
        pageSize,
        search: search || undefined,
      });
    }

    res.json(result);
  } catch (error) {
    if (error.code === 'INVALID_CHAIN_ID') {
      return res.status(400).json({
        message: error.message,
        chainId: requestedChainId,
        availableChains: error.availableChains,
      });
    }

    if (error.code === 'NOT_SUPPORTED') {
      // Gracefully return empty data with warning so frontend doesn't break.
      return res.status(200).json({
        data: [],
        chain: { id: requestedChainId, name: error.chainName },
        pagination: { page, pageSize, resultCount: 0, totalRaw: 0, total: 0, hasMore: false },
        supply: { totalSupply: null },
        warning: error.message,
        timestamp: Date.now(),
      });
    }

    if (error.code === 'UPSTREAM_ERROR') {
      return res.status(502).json({
        message: error.message,
        upstreamResponse: error.upstreamResponse,
      });
    }

    res.status(500).json({ message: 'Failed to fetch holders', error: error.message });
  }
};

module.exports = {
  getHolders,
};

const dexTradesService = require('../services/dexTradesService');

const getDexTrades = async (req, res) => {
  console.log(`[${new Date().toISOString()}] Received request for /api/dex-trades`);

  const requestedChainId = Number(req.query.chainId || 0);
  const page = Math.max(1, Number(req.query.page || 1));
  const pageSize = Math.min(200, Math.max(10, Number(req.query.pageSize || 25)));
  const sortParam = typeof req.query.sort === 'string' ? req.query.sort.toLowerCase() : 'desc';
  const sort = sortParam === 'asc' ? 'asc' : 'desc';
  const address = req.query.address ? String(req.query.address).trim() : undefined;
  const pool = req.query.pool ? String(req.query.pool).trim() : undefined;
  const hash = req.query.hash ? String(req.query.hash).trim() : undefined;

  try {
    const result = await dexTradesService.fetchDexTrades({
      chainId: requestedChainId,
      page,
      pageSize,
      sort,
      address,
      pool,
      hash,
    });

    res.json(result);
  } catch (error) {
    console.error('Error handling /api/dex-trades request:', error.message || error);
    res.status(500).json({
      message: 'Failed to fetch DEX trades',
      error: error.message || String(error),
    });
  }
};

module.exports = {
  getDexTrades,
};

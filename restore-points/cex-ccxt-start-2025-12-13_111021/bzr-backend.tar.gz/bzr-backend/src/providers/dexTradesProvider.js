'use strict';

const axios = require('axios');
const {
  buildProviderRequest,
  getProviderKeyForChain,
  getProviderConfigForChain,
} = require('../config/chains');
const { markApiKeyAsFailed, shouldBackoffApiKey } = require('../utils/apiUtils');
const { hexToNumberSafe } = require('./transfersProvider');

const SWAP_V2_TOPIC = '0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822';
const SWAP_V3_TOPIC = '0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67';

const DEFAULT_LOG_BLOCK_RANGE = Number(process.env.DEX_LOG_BLOCK_RANGE || 5_000);
const DEFAULT_LOG_TIMEOUT_MS = Number(process.env.DEX_LOG_TIMEOUT_MS || 25_000);
const DEFAULT_LOG_RETRIES = Number(process.env.DEX_LOG_RETRIES || 2);
const DEFAULT_LOG_RETRY_BASE_MS = Number(process.env.DEX_LOG_RETRY_BASE_MS || 800);
const DEFAULT_LOG_WINDOW_DELAY_MS = Number(process.env.DEX_LOG_WINDOW_DELAY_MS || 150);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const parseLogsResult = (payload = {}) => {
  const result = payload?.result;
  if (Array.isArray(result)) return result;
  if (typeof result === 'string') {
    const lower = result.toLowerCase();
    if (lower.includes('no records') || lower.includes('no logs')) return [];
  }
  return [];
};

const isHexResult = (value) =>
  typeof value === 'string' && /^0x[0-9a-f]+$/i.test(value.trim());

const fetchLatestBlockNumberForChain = async (chain) => {
  const blockNumberParams =
    getProviderKeyForChain(chain) === 'cronos'
      ? { module: 'block', action: 'eth_block_number' }
      : { module: 'proxy', action: 'eth_blockNumber' };

  const { provider, params, apiKey } = buildProviderRequest(chain, blockNumberParams);

  try {
    const response = await axios.get(provider.baseUrl, { params });
    const payload = response?.data || {};
    if (isHexResult(payload.result)) {
      return hexToNumberSafe(payload.result.trim());
    }

    const error = new Error(
      typeof payload.result === 'string'
        ? payload.result
        : payload?.message || 'Invalid block number payload'
    );
    error.code = 'PROXY_BLOCKNUMBER_INVALID_RESULT';
    error.payload = payload;
    throw error;
  } catch (error) {
    if (apiKey) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('invalid api key') || msg.includes('missing api key') || msg.includes('apikey invalid')) {
        markApiKeyAsFailed(apiKey, {
          reason: `dex_block_number_${chain.id}_invalid_key`,
          backoffMs: 24 * 60 * 60 * 1000,
        });
      } else if (shouldBackoffApiKey(error)) {
        markApiKeyAsFailed(apiKey, { reason: `dex_block_number_${chain.id}_rate_limit` });
      }
    }
    throw error;
  }
};

const fetchLogsWindow = async ({ chain, fromBlock, toBlock, address, topic0 }) => {
  const baseProvider = getProviderConfigForChain(chain);
  const requestParams = {
    module: 'logs',
    action: 'getLogs',
    fromBlock,
    toBlock,
    address,
  };
  if (topic0) requestParams.topic0 = topic0;

  let attempt = 0;
  while (attempt <= DEFAULT_LOG_RETRIES) {
    let provider;
    let params;
    let apiKey;
    try {
      ({ provider, params, apiKey } = buildProviderRequest(chain, requestParams));
      const targetBaseUrl = baseProvider.logsBaseUrl || provider.baseUrl;
      const response = await axios.get(targetBaseUrl, { params, timeout: DEFAULT_LOG_TIMEOUT_MS });
      const payload = response?.data || {};
      const status = typeof payload.status === 'string' ? payload.status : String(payload.status || '');
      const message = typeof payload.message === 'string' ? payload.message : String(payload.message || '');
      const result = payload?.result;
      if (status === '0' && typeof result === 'string') {
        const lowerResult = result.toLowerCase();
        const lowerMessage = message.toLowerCase();
        const isNoRecords =
          lowerResult.includes('no records') ||
          lowerResult.includes('no logs') ||
          lowerMessage.includes('no records') ||
          lowerMessage.includes('no logs');

        if (isNoRecords) {
          return [];
        }

        const err = new Error(result || message || 'Upstream logs error');
        err.code = 'DEX_LOGS_NOTOK';
        err.payload = payload;

        if (apiKey) {
          const invalidKey =
            lowerResult.includes('invalid api key') ||
            lowerResult.includes('missing api key') ||
            lowerResult.includes('apikey invalid') ||
            lowerResult.includes('invalid key');
          if (invalidKey) {
            markApiKeyAsFailed(apiKey, {
              reason: `dex_logs_${chain.id}_invalid_key`,
              backoffMs: 24 * 60 * 60 * 1000,
            });
          } else if (shouldBackoffApiKey(err)) {
            markApiKeyAsFailed(apiKey, { reason: `dex_logs_${chain.id}_rate_limit` });
          }
        }

        throw err;
      }
      return parseLogsResult(payload);
    } catch (error) {
      const status = error?.response?.status;
      const code = error?.code;
      const message = String(error?.message || '').toLowerCase();
      const retryable =
        [429, 500, 502, 503, 504].includes(status) ||
        ['ECONNRESET', 'ETIMEDOUT', 'ECONNABORTED', 'EAI_AGAIN'].includes(code) ||
        message.includes('socket hang up') ||
        message.includes('timeout') ||
        shouldBackoffApiKey(error);

      if (apiKey && shouldBackoffApiKey(error)) {
        markApiKeyAsFailed(apiKey, { reason: `dex_logs_${chain.id}_rate_limit` });
      }

      if (!retryable || attempt === DEFAULT_LOG_RETRIES) {
        throw error;
      }

      const delay = DEFAULT_LOG_RETRY_BASE_MS * Math.pow(2, attempt);
      await sleep(delay);
      attempt += 1;
    }
  }

  return [];
};

const fetchSwapLogsForPool = async ({
  chain,
  poolAddress,
  fromBlock,
  toBlock,
}) => {
  const start = Number.isFinite(fromBlock) ? fromBlock : 0;
  const end = Number.isFinite(toBlock) ? toBlock : await fetchLatestBlockNumberForChain(chain);
  const range = DEFAULT_LOG_BLOCK_RANGE > 0 ? DEFAULT_LOG_BLOCK_RANGE : 5_000;

  let currentFrom = start;
  const collected = [];
  let lastScannedBlock = start - 1;
  let complete = true;

  while (currentFrom <= end) {
    const currentTo = Math.min(end, currentFrom + (range - 1));

    try {
      // Fetch only Swap events to keep payloads small and avoid timeouts.
      const v2Logs = await fetchLogsWindow({
        chain,
        fromBlock: currentFrom,
        toBlock: currentTo,
        address: poolAddress,
        topic0: SWAP_V2_TOPIC,
      });
      const v3Logs = await fetchLogsWindow({
        chain,
        fromBlock: currentFrom,
        toBlock: currentTo,
        address: poolAddress,
        topic0: SWAP_V3_TOPIC,
      });

      collected.push(...(v2Logs || []), ...(v3Logs || []));
      lastScannedBlock = currentTo;
    } catch (error) {
      // Stop on errors and resume from the last successful window next run.
      console.warn(`! DEX logs window failed (${chain.id} ${poolAddress} ${currentFrom}-${currentTo}):`, error?.message || error);
      complete = false;
      break;
    }

    if (DEFAULT_LOG_WINDOW_DELAY_MS > 0) {
      await sleep(DEFAULT_LOG_WINDOW_DELAY_MS);
    }
    currentFrom = currentTo + 1;
  }

  return { logs: collected, lastScannedBlock, complete };
};

module.exports = {
  SWAP_V2_TOPIC,
  SWAP_V3_TOPIC,
  fetchLatestBlockNumberForChain,
  fetchSwapLogsForPool,
};

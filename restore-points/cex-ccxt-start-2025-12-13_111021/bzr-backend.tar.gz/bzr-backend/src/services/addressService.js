'use strict';

const axios = require('axios');
const {
  CHAINS,
  getChainDefinition,
  getProviderKeyForChain,
  buildProviderRequest,
} = require('../config/chains');
const { getTokenAddress } = require('./configService');
const { mapWithConcurrency } = require('../utils/concurrency');
const { shouldBackoffApiKey, markApiKeyAsFailed } = require('../utils/apiUtils');
const { query } = require('../utils/db');

const MAX_CONCURRENT_REQUESTS = Number(process.env.ETHERSCAN_CONCURRENCY || 3);
const ADDRESS_CACHE_TTL_MS = Number(process.env.ADDRESS_CACHE_TTL_MS || 60_000);

const addressCache = new Map(); // address -> { payload, timestamp }
const addressPromises = new Map();

const bigIntToFloat = (value, decimals = 18) => {
  try {
    const bi = BigInt(value);
    const denom = BigInt(10) ** BigInt(decimals);
    const whole = bi / denom;
    const frac = bi % denom;
    const fracStr = frac.toString().padStart(decimals, '0').slice(0, 6); // 6dp for display
    return Number(`${whole.toString()}.${fracStr}`);
  } catch {
    return 0;
  }
};

const fetchTokenBalanceForChain = async ({ chain, address, tokenAddress }) => {
  if (getProviderKeyForChain(chain) === 'cronos') {
    // Best effort: try the same Etherscan-style endpoint via Cronos proxy. If it fails, return null.
  }

  const { provider, params, apiKey } = buildProviderRequest(chain, {
    module: 'account',
    action: 'tokenbalance',
    contractaddress: tokenAddress,
    address,
    tag: 'latest',
  });

  try {
    const response = await axios.get(provider.baseUrl, { params, timeout: 10_000 });
    const payload = response?.data || {};
    const resultRaw = typeof payload.result === 'string' ? payload.result : '0';

    if (payload.status === '0' && payload.message && !String(payload.message).toLowerCase().includes('no')) {
      const error = new Error(payload.result || payload.message || 'Upstream error');
      error.code = 'UPSTREAM_ERROR';
      error.upstreamResponse = payload;
      throw error;
    }

    return {
      chainId: chain.id,
      chainName: chain.name,
      balanceRaw: resultRaw,
      balance: bigIntToFloat(resultRaw, 18),
      stale: false,
      source: 'network',
    };
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `address_balance_${chain.id}_rate_limit` });
    }
    return {
      chainId: chain.id,
      chainName: chain.name,
      balanceRaw: null,
      balance: null,
      stale: true,
      source: 'unavailable',
      error: error.message || String(error),
    };
  }
};

const fetchActivitySummary = async (address) => {
  try {
    const countResult = await query(
      `
      SELECT COUNT(*) AS count, COUNT(DISTINCT chain_id) AS chains
      FROM transfer_events
      WHERE from_address = $1 OR to_address = $1
    `,
      [address.toLowerCase()]
    );

    const count = Number(countResult.rows[0]?.count || 0);
    const chains = Number(countResult.rows[0]?.chains || 0);

    const recentResult = await query(
      `
      SELECT tx_hash, block_number, time_stamp, from_address, to_address, value, chain_id
      FROM transfer_events
      WHERE from_address = $1 OR to_address = $1
      ORDER BY time_stamp DESC NULLS LAST
      LIMIT 20
    `,
      [address.toLowerCase()]
    );

    const recentTransfers = recentResult.rows.map((row) => {
      const chainDef = getChainDefinition(row.chain_id);
      const tsSeconds = row.time_stamp
        ? Math.floor(new Date(row.time_stamp).getTime() / 1000)
        : null;
      return {
        hash: row.tx_hash,
        blockNumber: String(row.block_number),
        timeStamp: tsSeconds ? String(tsSeconds) : '0',
        from: row.from_address,
        to: row.to_address,
        value: row.value,
        tokenSymbol: process.env.BZR_TOKEN_SYMBOL || 'BZR',
        tokenDecimal: Number(process.env.BZR_TOKEN_DECIMALS || 18),
        tokenName: process.env.BZR_TOKEN_NAME || 'Bazaars',
        chainId: row.chain_id,
        chainName: chainDef?.name || `Chain ${row.chain_id}`,
      };
    });

    return { transferCount: count, chainCount: chains, recentTransfers };
  } catch (error) {
    // DB not configured or query failed – return empty activity.
    return { transferCount: null, chainCount: null, recentTransfers: [] };
  }
};

const getAddressDetails = async ({ address }) => {
  const cacheKey = address.toLowerCase();
  const cached = addressCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < ADDRESS_CACHE_TTL_MS) {
    return { ...cached.payload, stale: false, source: 'cache' };
  }

  let promise = addressPromises.get(cacheKey);
  if (!promise) {
    promise = (async () => {
      const tokenAddress = getTokenAddress();
      if (!tokenAddress) {
        throw new Error('Token address is not configured');
      }

      const balances = await mapWithConcurrency(
        CHAINS,
        MAX_CONCURRENT_REQUESTS,
        (chain) => fetchTokenBalanceForChain({ chain, address, tokenAddress })
      );

      const totalBalance = balances.reduce((acc, b) => {
        if (typeof b.balance === 'number' && Number.isFinite(b.balance)) {
          return acc + b.balance;
        }
        return acc;
      }, 0);

      const activity = await fetchActivitySummary(address);

      const payload = {
        address,
        tokenAddress,
        balances,
        totalBalance,
        activity,
        timestamp: Date.now(),
        stale: balances.some((b) => b.stale),
        source: 'network',
      };

      addressCache.set(cacheKey, { payload, timestamp: Date.now() });
      return payload;
    })().finally(() => {
      addressPromises.delete(cacheKey);
    });

    addressPromises.set(cacheKey, promise);
  }

  return await promise;
};

module.exports = { getAddressDetails };


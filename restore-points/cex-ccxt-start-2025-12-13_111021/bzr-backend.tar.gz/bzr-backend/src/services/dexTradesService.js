'use strict';

const axios = require('axios');
const { query, getDbPool } = require('../utils/db');
const { CHAINS, getChainDefinition, buildProviderRequest, getProviderKeyForChain, getProviderConfigForChain } = require('../config/chains');
const { markApiKeyAsFailed, shouldBackoffApiKey } = require('../utils/apiUtils');
const { mapWithConcurrency } = require('../utils/concurrency');
const { fetchSwapLogsForPool, fetchLatestBlockNumberForChain } = require('../providers/dexTradesProvider');
const { hexToNumberSafe, BZR_TOKEN_DECIMALS } = require('../providers/transfersProvider');
const { getTokenAddress } = require('./configService');
const { fetchTokenPrice } = require('./tokenService');

const DEX_POOL_CONCURRENCY = Number(process.env.DEX_POOL_CONCURRENCY || 2);
const DEX_BACKFILL_START_BLOCK = Number(process.env.DEX_BACKFILL_START_BLOCK || 0);
const DEX_LOG_LOOKBACK_BLOCKS = Number(process.env.DEX_LOG_LOOKBACK_BLOCKS || 500_000);
const DEX_LOG_DECODE_CONCURRENCY = Number(process.env.DEX_LOG_DECODE_CONCURRENCY || 8);

const COINGECKO_BASE_URL = process.env.COINGECKO_BASE_URL || 'https://api.coingecko.com/api/v3';
const COINGECKO_TIMEOUT_MS = Number(process.env.COINGECKO_TIMEOUT_MS || 10_000);
const COINGECKO_CACHE_TTL_MS = Number(process.env.COINGECKO_CACHE_TTL_MS || 60 * 60 * 1000); // 1h

const SWAP_V2_TOPIC = require('../providers/dexTradesProvider').SWAP_V2_TOPIC;
const SWAP_V3_TOPIC = require('../providers/dexTradesProvider').SWAP_V3_TOPIC;

const DEXSCREENER_CHAIN_MAP = {
  ethereum: 1,
  eth: 1,
  optimism: 10,
  op: 10,
  bsc: 56,
  binance: 56,
  polygon: 137,
  pol: 137,
  zksync: 324,
  mantle: 5000,
  arb: 42161,
  arbitrum: 42161,
  avax: 43114,
  avalanche: 43114,
  base: 8453,
  cronos: 25,
};

const normalizeAddress = (value) => (typeof value === 'string' ? value.toLowerCase() : null);
const normalizeSymbol = (value) => {
  if (!value) return null;
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
};

const STABLECOIN_SYMBOLS = new Set([
  'usdc',
  'usdt',
  'dai',
  'busd',
  'tusd',
  'frax',
  'usde',
  'lusd',
  'susd',
]);

// Some chains use non-standard symbols or non-6 decimals for stablecoins (e.g. BSC USDT is 18 decimals).
// Prefer address-based overrides when available to keep USD values accurate.
const QUOTE_TOKEN_OVERRIDES = new Map([
  // BSC USDT (0x55d398...): 18 decimals
  ['56:0x55d398326f99059ff775485246999027b3197955', { symbol: 'usdt', decimals: 18, usd: 1 }],
  // Arbitrum USDT (0xfd086...): 6 decimals, DexScreener symbol may appear as "USD₮0"
  ['42161:0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9', { symbol: 'usdt', decimals: 6, usd: 1 }],
  // Avalanche USDt (0x970223...): 6 decimals
  ['43114:0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7', { symbol: 'usdt', decimals: 6, usd: 1 }],
  // Optimism USDC (0x0b2c63...): 6 decimals
  ['10:0x0b2c639c533813f4aa9d7837caf62653d097ff85', { symbol: 'usdc', decimals: 6, usd: 1 }],
]);

const QUOTE_DECIMALS_BY_SYMBOL = {
  usdc: 6,
  usdt: 6,
  dai: 18,
  busd: 18,
  tusd: 18,
  frax: 18,
  usde: 18,
  lusd: 18,
  susd: 18,
};

const COINGECKO_ID_BY_SYMBOL = {
  eth: 'ethereum',
  weth: 'ethereum',
  bnb: 'binancecoin',
  wbnb: 'binancecoin',
  matic: 'polygon-ecosystem-token',
  wmatic: 'polygon-ecosystem-token',
  avax: 'avalanche-2',
  wavax: 'avalanche-2',
  cro: 'crypto-com-chain',
  wcro: 'crypto-com-chain',
};

const quoteUsdCache = new Map();

const getQuoteOverride = (chainId, tokenAddress) => {
  const normalizedChainId = Number(chainId);
  const normalizedAddress = normalizeAddress(tokenAddress);
  if (!normalizedChainId || !normalizedAddress) return null;
  return QUOTE_TOKEN_OVERRIDES.get(`${normalizedChainId}:${normalizedAddress}`) || null;
};

const getQuoteDecimals = (quoteSymbol) => {
  const normalized = normalizeSymbol(quoteSymbol);
  if (!normalized) return 18;
  return QUOTE_DECIMALS_BY_SYMBOL[normalized] ?? 18;
};

const fetchCoingeckoUsdAt = async (coinId, timeStampSeconds) => {
  if (!coinId || !timeStampSeconds) return null;

  const bucket = Math.floor(Number(timeStampSeconds) / 3600);
  if (!Number.isFinite(bucket)) return null;

  const cacheKey = `${coinId}:${bucket}`;
  const now = Date.now();
  const cached = quoteUsdCache.get(cacheKey);
  if (cached && now - cached.fetchedAt < COINGECKO_CACHE_TTL_MS) {
    return cached.priceUsd ?? null;
  }

  const from = bucket * 3600 - 3600;
  const to = bucket * 3600 + 3600;

  try {
    const resp = await axios.get(`${COINGECKO_BASE_URL}/coins/${coinId}/market_chart/range`, {
      params: {
        vs_currency: 'usd',
        from,
        to,
      },
      timeout: COINGECKO_TIMEOUT_MS,
    });

    const prices = resp.data?.prices;
    if (!Array.isArray(prices) || prices.length === 0) {
      quoteUsdCache.set(cacheKey, { priceUsd: null, fetchedAt: now });
      return null;
    }

    const targetMs = Number(timeStampSeconds) * 1000;
    let bestPrice = null;
    let bestDiff = Infinity;
    for (const point of prices) {
      if (!Array.isArray(point) || point.length < 2) continue;
      const [ms, price] = point;
      const diff = Math.abs(Number(ms) - targetMs);
      if (diff < bestDiff) {
        bestDiff = diff;
        bestPrice = Number(price);
      }
    }

    const priceUsd = Number.isFinite(bestPrice) ? bestPrice : null;
    quoteUsdCache.set(cacheKey, { priceUsd, fetchedAt: now });
    return priceUsd;
  } catch (error) {
    quoteUsdCache.set(cacheKey, { priceUsd: null, fetchedAt: now });
    return null;
  }
};

const resolveQuoteUsdAt = async (quoteSymbol, timeStampSeconds) => {
  const normalized = normalizeSymbol(quoteSymbol);
  if (!normalized || !timeStampSeconds) return null;
  if (STABLECOIN_SYMBOLS.has(normalized)) return 1;

  const coinId = COINGECKO_ID_BY_SYMBOL[normalized];
  if (!coinId) return null;

  return fetchCoingeckoUsdAt(coinId, timeStampSeconds);
};

const int256FromHex = (hex) => {
  let value = BigInt(`0x${hex}`);
  if ((value >> 255n) === 1n) {
    value -= 1n << 256n;
  }
  return value;
};

const decodeUint256 = (hex) => BigInt(`0x${hex || '0'}`);

const sliceWords = (data, count) => {
  const clean = (data || '').replace(/^0x/i, '').padStart(count * 64, '0');
  const words = [];
  for (let i = 0; i < count; i += 1) {
    words.push(clean.slice(i * 64, (i + 1) * 64));
  }
  return words;
};

const topicToAddress = (topic) => {
  if (typeof topic !== 'string' || topic.length < 42) return null;
  return `0x${topic.slice(-40).toLowerCase()}`;
};

const parseAddressFromCallResult = (result) => {
  if (typeof result !== 'string' || !result.startsWith('0x')) return null;
  return `0x${result.slice(-40).toLowerCase()}`;
};

const ethCall = async (chain, to, data) => {
  if (getProviderKeyForChain(chain) !== 'etherscan') {
    return null;
  }

  const { provider, params, apiKey } = buildProviderRequest(chain, {
    module: 'proxy',
    action: 'eth_call',
    to,
    data,
    tag: 'latest',
  });

  try {
    const response = await axios.get(provider.baseUrl, { params, timeout: 12_000 });
    const payload = response?.data || {};
    return parseAddressFromCallResult(payload.result);
  } catch (error) {
    if (apiKey && shouldBackoffApiKey(error)) {
      markApiKeyAsFailed(apiKey, { reason: `dex_eth_call_${chain.id}_rate_limit` });
    }
    return null;
  }
};

const hydratePoolTokenOrder = async (pool, chain) => {
  if (pool.token0Address && pool.token1Address) return pool;
  const [token0, token1] = await Promise.all([
    ethCall(chain, pool.poolAddress, '0x0dfe1681'),
    ethCall(chain, pool.poolAddress, '0xd21220a7'),
  ]);

  if (token0 && token1) {
    await query(
      `
      UPDATE dex_pools
      SET token0_address = $3,
          token1_address = $4
      WHERE chain_id = $1 AND pool_address = $2
      `,
      [pool.chainId, pool.poolAddress, token0, token1]
    );

    return { ...pool, token0Address: token0, token1Address: token1 };
  }

  return pool;
};

const discoverPoolsFromDexscreener = async () => {
  const tokenAddress = normalizeAddress(getTokenAddress());
  if (!tokenAddress) {
    throw new Error('Token address is not configured');
  }

  const endpoint = `https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(tokenAddress)}`;
  const response = await axios.get(endpoint, { timeout: 8_000 });
  const pairs = response.data?.pairs || [];

  const pools = [];
  for (const pair of pairs) {
    const chainKey = String(pair.chainId || pair.chain || '').toLowerCase();
    const chainId = DEXSCREENER_CHAIN_MAP[chainKey];
    if (!chainId) continue;
    const chainDef = getChainDefinition(chainId);
    if (!chainDef) continue;

    const baseAddress = normalizeAddress(pair.baseToken?.address);
    const quoteAddress = normalizeAddress(pair.quoteToken?.address);
    if (baseAddress !== tokenAddress && quoteAddress !== tokenAddress) continue;

    const poolAddress = normalizeAddress(pair.pairAddress || pair.pairAddress?.address || pair.address);
    if (!poolAddress) continue;

    const createdAtMs = Number(pair.pairCreatedAt);
    const createdAt = Number.isFinite(createdAtMs) && createdAtMs > 0 ? new Date(createdAtMs) : null;

    pools.push({
      chainId,
      poolAddress,
      dexId: pair.dexId || null,
      baseTokenAddress: baseAddress,
      quoteTokenAddress: quoteAddress,
      quoteSymbol: pair.quoteToken?.symbol || null,
      createdAt,
      meta: {
        dexId: pair.dexId,
        liquidityUsd: pair.liquidity?.usd || null,
        url: pair.url || null,
      },
    });
  }

  if (!pools.length) {
    return [];
  }

  const clientPool = getDbPool();
  if (!clientPool) {
    throw new Error('Database not configured');
  }

  const values = [];
  const placeholders = [];
  let idx = 1;
  for (const pool of pools) {
    placeholders.push(
      `($${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++})`
    );
    values.push(
      pool.chainId,
      pool.poolAddress,
      pool.dexId,
      pool.baseTokenAddress,
      pool.quoteTokenAddress,
      pool.quoteSymbol,
      pool.createdAt,
      pool.meta
    );
  }

  await query(
    `
    INSERT INTO dex_pools (
      chain_id,
      pool_address,
      dex_id,
      base_token_address,
      quote_token_address,
      quote_symbol,
      created_at,
      meta
    )
    VALUES ${placeholders.join(',')}
    ON CONFLICT (chain_id, pool_address) DO UPDATE
    SET dex_id = EXCLUDED.dex_id,
        base_token_address = EXCLUDED.base_token_address,
        quote_token_address = EXCLUDED.quote_token_address,
        quote_symbol = EXCLUDED.quote_symbol,
        created_at = COALESCE(dex_pools.created_at, EXCLUDED.created_at),
        meta = COALESCE(EXCLUDED.meta, dex_pools.meta)
    `,
    values
  );

  return pools;
};

const loadPoolsFromDb = async (chainId = 0) => {
  const params = [];
  let whereClause = '';
  if (chainId && Number(chainId) !== 0) {
    params.push(Number(chainId));
    whereClause = 'WHERE chain_id = $1';
  }

  const res = await query(
    `
    SELECT
      chain_id as "chainId",
      pool_address as "poolAddress",
      dex_id as "dexId",
      base_token_address as "baseTokenAddress",
      quote_token_address as "quoteTokenAddress",
      token0_address as "token0Address",
      token1_address as "token1Address",
      created_block as "createdBlock",
      last_synced_block as "lastSyncedBlock",
      quote_symbol as "quoteSymbol",
      meta
    FROM dex_pools
    ${whereClause}
    ORDER BY chain_id, pool_address
    `,
    params
  );

  return res.rows || [];
};

const storeDexTrades = async (trades = []) => {
  if (!Array.isArray(trades) || trades.length === 0) return { inserted: 0 };

  const values = [];
  const placeholders = [];
  let idx = 1;

  for (const trade of trades) {
    placeholders.push(
      `($${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++})`
    );
    values.push(
      trade.chainId,
      trade.poolAddress,
      trade.txHash,
      trade.logIndex,
      trade.blockNumber,
      trade.timeStamp,
      trade.traderAddress,
      trade.side,
      trade.amountBzrRaw,
      trade.amountQuoteRaw,
      trade.priceUsd,
      trade.valueUsd,
      trade.quoteSymbol,
      trade.payload
    );
  }

  const res = await query(
    `
    INSERT INTO dex_trades (
      chain_id,
      pool_address,
      tx_hash,
      log_index,
      block_number,
      time_stamp,
      trader_address,
      side,
      amount_bzr_raw,
      amount_quote_raw,
      price_usd,
      value_usd,
      quote_symbol,
      payload
    )
    VALUES ${placeholders.join(',')}
    ON CONFLICT (chain_id, tx_hash, log_index) DO UPDATE
    SET
      pool_address = EXCLUDED.pool_address,
      block_number = EXCLUDED.block_number,
      time_stamp = EXCLUDED.time_stamp,
      trader_address = EXCLUDED.trader_address,
      side = EXCLUDED.side,
      amount_bzr_raw = EXCLUDED.amount_bzr_raw,
      amount_quote_raw = EXCLUDED.amount_quote_raw,
      price_usd = EXCLUDED.price_usd,
      value_usd = EXCLUDED.value_usd,
      quote_symbol = EXCLUDED.quote_symbol,
      payload = EXCLUDED.payload
    `,
    values
  );

  return { inserted: res.rowCount || 0 };
};

const bigIntToDecimal = (value, decimals = 18) => {
  if (value === null || value === undefined) return 0;
  const denom = 10n ** BigInt(decimals);
  const whole = value / denom;
  const frac = value % denom;
  const fracStr = frac.toString().padStart(decimals, '0').slice(0, 6);
  return Number(`${whole}.${fracStr}`);
};

const decodeSwapLog = async (log, pool, tokenAddressLower, fallbackTokenPriceUsd) => {
  const topic0 = normalizeAddress(log.topics?.[0]);
  const logIndex = hexToNumberSafe(log.logIndex);
  const blockNumber = hexToNumberSafe(log.blockNumber);
  const timeStampHex = log.timeStamp || log.time_stamp;
  const timeStampSeconds = timeStampHex ? hexToNumberSafe(timeStampHex) : null;
  const timeStamp = timeStampSeconds ? new Date(timeStampSeconds * 1000) : new Date();

  const token0 = normalizeAddress(pool.token0Address);
  const token1 = normalizeAddress(pool.token1Address);
  const bzrIsToken0 = token0 === tokenAddressLower;
  const bzrIsToken1 = token1 === tokenAddressLower;

  if (!bzrIsToken0 && !bzrIsToken1) {
    return null;
  }

  const quoteTokenAddress = bzrIsToken0 ? token1 : token0;
  const quoteOverride = getQuoteOverride(pool.chainId, quoteTokenAddress);

  let amountBzrRaw = 0n;
  let amountQuoteRaw = 0n;
  let side = null;
  let traderAddress = null;

  if (topic0 === SWAP_V2_TOPIC) {
    const [a0In, a1In, a0Out, a1Out] = sliceWords(log.data, 4).map(decodeUint256);
    if (bzrIsToken0) {
      amountBzrRaw = a0In > 0n ? a0In : a0Out;
      amountQuoteRaw = a1In > 0n ? a1In : a1Out;
      side = a0Out > 0n ? 'buy' : 'sell';
    } else {
      amountBzrRaw = a1In > 0n ? a1In : a1Out;
      amountQuoteRaw = a0In > 0n ? a0In : a0Out;
      side = a1Out > 0n ? 'buy' : 'sell';
    }
    traderAddress = topicToAddress(log.topics?.[1]);
  } else if (topic0 === SWAP_V3_TOPIC) {
    const [raw0, raw1] = sliceWords(log.data, 2).map(int256FromHex);
    if (bzrIsToken0) {
      const deltaBzr = raw0;
      const deltaQuote = raw1;
      amountBzrRaw = deltaBzr < 0n ? -deltaBzr : deltaBzr;
      amountQuoteRaw = deltaQuote < 0n ? -deltaQuote : deltaQuote;
      side = deltaBzr < 0n ? 'buy' : 'sell';
    } else {
      const deltaBzr = raw1;
      const deltaQuote = raw0;
      amountBzrRaw = deltaBzr < 0n ? -deltaBzr : deltaBzr;
      amountQuoteRaw = deltaQuote < 0n ? -deltaQuote : deltaQuote;
      side = deltaBzr < 0n ? 'buy' : 'sell';
    }
    traderAddress = topicToAddress(log.topics?.[2]) || topicToAddress(log.topics?.[1]);
  } else {
    return null;
  }

  const amountBzr = bigIntToDecimal(amountBzrRaw, BZR_TOKEN_DECIMALS);
  const quoteDecimals = quoteOverride?.decimals ?? getQuoteDecimals(pool.quoteSymbol);
  const amountQuote = bigIntToDecimal(amountQuoteRaw, quoteDecimals);
  const quoteUsd =
    quoteOverride?.usd ??
    (timeStampSeconds
      ? await resolveQuoteUsdAt(quoteOverride?.symbol ?? pool.quoteSymbol, timeStampSeconds)
      : null);

  let priceUsd = null;
  let valueUsd = null;
  let usdSource = null;

  if (quoteUsd !== null && amountQuote > 0 && amountBzr > 0) {
    valueUsd = amountQuote * quoteUsd;
    priceUsd = valueUsd / amountBzr;
    usdSource =
      quoteOverride?.usd === 1 || STABLECOIN_SYMBOLS.has(normalizeSymbol(pool.quoteSymbol))
        ? 'stable'
        : 'quote';
  } else if (fallbackTokenPriceUsd && amountBzr > 0) {
    priceUsd = fallbackTokenPriceUsd;
    valueUsd = amountBzr * fallbackTokenPriceUsd;
    usdSource = 'fallback';
  }

  return {
    chainId: pool.chainId,
    poolAddress: pool.poolAddress,
    txHash: log.transactionHash,
    logIndex,
    blockNumber,
    timeStamp,
    traderAddress,
    side,
    amountBzrRaw: amountBzrRaw.toString(),
    amountQuoteRaw: amountQuoteRaw.toString(),
    priceUsd,
    valueUsd,
    quoteSymbol: pool.quoteSymbol || null,
    payload: {
      ...log,
      decoded: {
        side,
        amountBzrRaw: amountBzrRaw.toString(),
        amountQuoteRaw: amountQuoteRaw.toString(),
        quoteDecimals,
        quoteUsd,
        usdSource,
        quoteTokenAddress,
      },
    },
  };
};

const backfillPool = async (pool, chain, tokenAddressLower, priceUsd) => {
  const debug = String(process.env.DEBUG_DEX_TRADES || '').toLowerCase() === '1';
  const hydrated = await hydratePoolTokenOrder(pool, chain);
  const latestBlock = await fetchLatestBlockNumberForChain(chain);
  const lookbackStart =
    Number.isFinite(DEX_LOG_LOOKBACK_BLOCKS) && DEX_LOG_LOOKBACK_BLOCKS > 0
      ? Math.max(0, latestBlock - DEX_LOG_LOOKBACK_BLOCKS)
      : 0;

  const baseStart = Number.isFinite(DEX_BACKFILL_START_BLOCK) ? DEX_BACKFILL_START_BLOCK : 0;
  const createdBlock =
    Number.isFinite(Number(hydrated.createdBlock)) && Number(hydrated.createdBlock) > 0
      ? Number(hydrated.createdBlock)
      : null;
  const lastSyncedBlock =
    Number.isFinite(Number(hydrated.lastSyncedBlock)) && Number(hydrated.lastSyncedBlock) > 0
      ? Number(hydrated.lastSyncedBlock)
      : null;

  const floorStart = Math.max(baseStart, lookbackStart);
  // If we keep only a rolling window, never start before the window floor even if an old cursor exists.
  let startBlock = lastSyncedBlock !== null ? Math.max(lastSyncedBlock + 1, floorStart) : floorStart;
  if (createdBlock !== null) {
    startBlock = Math.max(startBlock, createdBlock);
  }

  if (startBlock > latestBlock) {
    return { inserted: 0 };
  }

  if (debug) {
    const token0 = normalizeAddress(hydrated.token0Address);
    const token1 = normalizeAddress(hydrated.token1Address);
    console.log('[dex] backfillPool', {
      chainId: pool.chainId,
      pool: hydrated.poolAddress,
      latestBlock,
      startBlock,
      lookbackStart,
      token0,
      token1,
      bzrMatch: token0 === tokenAddressLower || token1 === tokenAddressLower,
    });
  }

  const scan = await fetchSwapLogsForPool({
    chain,
    poolAddress: hydrated.poolAddress,
    fromBlock: startBlock,
    toBlock: latestBlock,
  });
  const logs = scan?.logs || [];
  const lastScannedBlock =
    Number.isFinite(scan?.lastScannedBlock) && scan.lastScannedBlock >= startBlock
      ? scan.lastScannedBlock
      : null;
  const complete = Boolean(scan?.complete);

  const decoded = await mapWithConcurrency(logs, DEX_LOG_DECODE_CONCURRENCY, async (log) => {
    try {
      return await decodeSwapLog(log, hydrated, tokenAddressLower, priceUsd);
    } catch (error) {
      console.warn(`! DEX decode failed for tx ${log.transactionHash}:`, error.message || error);
      return null;
    }
  });
  const trades = (decoded || []).filter(Boolean);

  const stored = await storeDexTrades(trades);
  if (debug) {
    console.log('[dex] backfillPool result', {
      chainId: pool.chainId,
      pool: hydrated.poolAddress,
      logs: logs.length,
      trades: trades.length,
      inserted: stored.inserted,
      lastScannedBlock,
      complete,
    });
  }
  // Only advance the sync cursor when we actually scanned at least one full window successfully.
  if (lastScannedBlock !== null) {
    await query(
      `
      UPDATE dex_pools
      SET last_synced_block = $3,
          last_synced_at = NOW()
      WHERE chain_id = $1 AND pool_address = $2
      `,
      [pool.chainId, pool.poolAddress, complete ? latestBlock : lastScannedBlock]
    );
  }

  return stored;
};

const recomputeDexTradesUsd = async ({ chainId = 0, limit = 10_000 } = {}) => {
  const normalizedChainId = Number(chainId) || 0;
  const normalizedLimit = Math.min(50_000, Math.max(1, Number(limit) || 10_000));

  const params = [];
  let idx = 1;
  let whereClause = '';
  if (normalizedChainId !== 0) {
    whereClause = `WHERE t.chain_id = $${idx++}`;
    params.push(normalizedChainId);
  }

  const res = await query(
    `
    SELECT
      t.chain_id as "chainId",
      t.pool_address as "poolAddress",
      t.tx_hash as "txHash",
      t.log_index as "logIndex",
      FLOOR(EXTRACT(EPOCH FROM t.time_stamp))::bigint as "timeStamp",
      t.amount_bzr_raw as "amountBzrRaw",
      t.amount_quote_raw as "amountQuoteRaw",
      t.quote_symbol as "quoteSymbol",
      p.quote_token_address as "quoteTokenAddress"
    FROM dex_trades t
    LEFT JOIN dex_pools p
      ON p.chain_id = t.chain_id AND p.pool_address = t.pool_address
    ${whereClause}
    ORDER BY t.time_stamp DESC
    LIMIT $${idx}
    `,
    [...params, normalizedLimit]
  );

  const rows = res.rows || [];
  if (!rows.length) return { scanned: 0, updated: 0 };

  const fallbackPriceResult = await fetchTokenPrice().catch(() => null);
  const fallbackTokenPriceUsd =
    fallbackPriceResult?.priceUsd && Number.isFinite(fallbackPriceResult.priceUsd)
      ? fallbackPriceResult.priceUsd
      : null;

  let updated = 0;
  await mapWithConcurrency(rows, DEX_LOG_DECODE_CONCURRENCY, async (row) => {
    const timeStampSeconds = Number(row.timeStamp);
    if (!timeStampSeconds) return;

    const amountBzrRaw = row.amountBzrRaw ? BigInt(String(row.amountBzrRaw)) : 0n;
    const amountQuoteRaw = row.amountQuoteRaw ? BigInt(String(row.amountQuoteRaw)) : 0n;
    const amountBzr = bigIntToDecimal(amountBzrRaw, BZR_TOKEN_DECIMALS);
    if (!amountBzr) return;

    const quoteOverride = getQuoteOverride(row.chainId, row.quoteTokenAddress);
    const quoteDecimals = quoteOverride?.decimals ?? getQuoteDecimals(row.quoteSymbol);
    const amountQuote = bigIntToDecimal(amountQuoteRaw, quoteDecimals);

    const quoteUsd =
      quoteOverride?.usd ?? (await resolveQuoteUsdAt(quoteOverride?.symbol ?? row.quoteSymbol, timeStampSeconds));
    let valueUsd = null;
    let priceUsd = null;

    if (quoteUsd !== null && amountQuote > 0) {
      valueUsd = amountQuote * quoteUsd;
      priceUsd = valueUsd / amountBzr;
    } else if (fallbackTokenPriceUsd && amountBzr > 0) {
      priceUsd = fallbackTokenPriceUsd;
      valueUsd = amountBzr * fallbackTokenPriceUsd;
    }

    if (priceUsd === null || valueUsd === null) return;

    await query(
      `
      UPDATE dex_trades
      SET price_usd = $1,
          value_usd = $2
      WHERE chain_id = $3 AND tx_hash = $4 AND log_index = $5
      `,
      [priceUsd, valueUsd, row.chainId, row.txHash, row.logIndex]
    );
    updated += 1;
  });

  return { scanned: rows.length, updated };
};

const discoverAndBackfillDexTrades = async ({ chainId = 0 } = {}) => {
  const tokenAddressLower = normalizeAddress(getTokenAddress());
  if (!tokenAddressLower) {
    throw new Error('Token address is not configured');
  }

  // 1) Discover pools via DexScreener
  await discoverPoolsFromDexscreener();

  // 2) Load pools from DB
  const pools = await loadPoolsFromDb(chainId);
  if (!pools.length) {
    return { pools: 0, inserted: 0 };
  }

  const priceResult = await fetchTokenPrice().catch(() => null);
  const priceUsd = priceResult?.priceUsd && Number.isFinite(priceResult.priceUsd) ? priceResult.priceUsd : null;

  let insertedTotal = 0;
  await mapWithConcurrency(pools, DEX_POOL_CONCURRENCY, async (pool) => {
    const chain = getChainDefinition(pool.chainId);
    if (!chain) return;
    try {
      const res = await backfillPool(pool, chain, tokenAddressLower, priceUsd);
      insertedTotal += res.inserted || 0;
    } catch (error) {
      // Keep going; log and continue
      console.warn(`! DEX backfill failed for pool ${pool.poolAddress} on ${chain.name}:`, error.message || error);
    }
  });

  return { pools: pools.length, inserted: insertedTotal, priceUsd };
};

const fetchDexTrades = async ({
  chainId = 0,
  page = 1,
  pageSize = 25,
  sort = 'desc',
  address,
  pool,
  hash,
} = {}) => {
  const normalizedChainId = Number(chainId) || 0;
  const normalizedPage = Math.max(1, Number(page) || 1);
  const normalizedPageSize = Math.min(200, Math.max(10, Number(pageSize) || 25));
  const direction = String(sort).toLowerCase() === 'asc' ? 'ASC' : 'DESC';

  const where = [];
  const params = [];
  let idx = 1;

  if (normalizedChainId !== 0) {
    where.push(`t.chain_id = $${idx++}`);
    params.push(normalizedChainId);
  }

  const normalizedAddress = normalizeAddress(address);
  if (normalizedAddress) {
    where.push(`t.trader_address = $${idx++}`);
    params.push(normalizedAddress);
  }

  const normalizedPool = normalizeAddress(pool);
  if (normalizedPool) {
    where.push(`t.pool_address = $${idx++}`);
    params.push(normalizedPool);
  }

  const normalizedHash =
    typeof hash === 'string' && hash.trim().startsWith('0x')
      ? hash.trim().toLowerCase()
      : null;
  if (normalizedHash) {
    where.push(`LOWER(t.tx_hash) = $${idx++}`);
    params.push(normalizedHash);
  }

  const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const offset = (normalizedPage - 1) * normalizedPageSize;

  const countRes = await query(
    `SELECT COUNT(*)::bigint AS total FROM dex_trades t ${whereClause}`,
    params
  );
  const total = Number(countRes.rows?.[0]?.total || 0);

  const dataRes = await query(
    `
    SELECT
      t.chain_id as "chainId",
      t.pool_address as "poolAddress",
      p.dex_id as "dexId",
      t.tx_hash as "txHash",
      t.log_index as "logIndex",
      t.block_number::double precision as "blockNumber",
      FLOOR(EXTRACT(EPOCH FROM t.time_stamp))::double precision as "timeStamp",
      t.trader_address as "traderAddress",
      t.side,
      t.amount_bzr_raw as "amountBzrRaw",
      t.amount_quote_raw as "amountQuoteRaw",
      t.price_usd::double precision as "priceUsd",
      t.value_usd::double precision as "valueUsd",
      t.quote_symbol as "quoteSymbol",
      t.payload
    FROM dex_trades t
    LEFT JOIN dex_pools p
      ON p.chain_id = t.chain_id
     AND p.pool_address = t.pool_address
    ${whereClause}
    ORDER BY t.block_number ${direction}, t.log_index ${direction}
    LIMIT $${idx++} OFFSET $${idx++}
    `,
    [...params, normalizedPageSize, offset]
  );

  const rows = dataRes.rows || [];
  const hasMore = offset + rows.length < total;

  const supportedChainRows = await query(
    `SELECT DISTINCT chain_id::int AS id FROM dex_pools ORDER BY chain_id::int ASC`
  );
  const supportedChains = (supportedChainRows.rows || [])
    .map((row) => {
      const id = Number(row.id);
      const chain = getChainDefinition(id);
      return { id, name: chain?.name || String(id) };
    })
    .filter((c) => Number.isFinite(c.id));

  return {
    data: rows,
    chain: normalizedChainId === 0 ? { id: 0, name: 'All Chains' } : getChainDefinition(normalizedChainId),
    supportedChains,
    pagination: {
      page: normalizedPage,
      pageSize: normalizedPageSize,
      resultCount: rows.length,
      total,
      hasMore,
    },
    timestamp: Date.now(),
  };
};

module.exports = {
  discoverPoolsFromDexscreener,
  loadPoolsFromDb,
  discoverAndBackfillDexTrades,
  fetchDexTrades,
  recomputeDexTradesUsd,
};

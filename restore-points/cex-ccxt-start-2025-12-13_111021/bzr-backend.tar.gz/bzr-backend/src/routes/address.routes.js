const express = require('express');
const addressController = require('../controllers/addressController');
const { strictLimiter } = require('../middleware/rateLimiters');
const cacheMiddleware = require('../middleware/cacheMiddleware');

const router = express.Router();

// Cache per-address responses briefly to reduce provider load.
router.get('/address/:address', strictLimiter, cacheMiddleware(60), addressController.getAddressDetails);

module.exports = router;


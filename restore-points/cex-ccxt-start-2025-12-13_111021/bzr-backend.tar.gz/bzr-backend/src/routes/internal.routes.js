const express = require('express');
const internalController = require('../controllers/internalController');
const { strictLimiter } = require('../middleware/rateLimiters');
const cacheMiddleware = require('../middleware/cacheMiddleware');

const router = express.Router();

// Cache internal transfers for 60s; upstream is expensive.
router.get('/internal-transfers', strictLimiter, cacheMiddleware(60), internalController.getInternalTransfers);

module.exports = router;


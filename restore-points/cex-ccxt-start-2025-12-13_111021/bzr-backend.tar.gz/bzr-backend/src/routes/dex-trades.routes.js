const express = require('express');
const dexTradesController = require('../controllers/dexTradesController');
const { strictLimiter } = require('../middleware/rateLimiters');
const cacheMiddleware = require('../middleware/cacheMiddleware');

const router = express.Router();

// Cache for 60 seconds — data is DB-backed and refreshed separately.
router.get('/', strictLimiter, cacheMiddleware(60), dexTradesController.getDexTrades);

module.exports = router;


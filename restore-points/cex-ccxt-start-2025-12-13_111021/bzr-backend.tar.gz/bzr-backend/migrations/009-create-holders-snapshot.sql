-- Holders snapshot storage for speed/accuracy and fallbacks
CREATE TABLE IF NOT EXISTS holders_snapshot (
  chain_id INTEGER NOT NULL,
  address TEXT NOT NULL,
  balance NUMERIC(78, 18) NOT NULL,
  last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (chain_id, address)
);

-- Fast ordering by balance per chain
CREATE INDEX IF NOT EXISTS holders_snapshot_chain_balance_idx
  ON holders_snapshot (chain_id, balance DESC);

-- Chain filter only
CREATE INDEX IF NOT EXISTS holders_snapshot_chain_idx
  ON holders_snapshot (chain_id);

-- Migration: 011-create-dex-tables.sql
-- Created at: 2025-12-12
-- Description: Schema for DEX pools and derived swap trades (TokenTrade tab)

BEGIN;

CREATE TABLE IF NOT EXISTS dex_pools (
  id BIGSERIAL PRIMARY KEY,
  chain_id INTEGER NOT NULL,
  pool_address TEXT NOT NULL,
  dex_id TEXT,
  base_token_address TEXT,
  quote_token_address TEXT,
  quote_symbol TEXT,
  token0_address TEXT,
  token1_address TEXT,
  created_block BIGINT,
  created_at TIMESTAMPTZ,
  last_synced_block BIGINT,
  last_synced_at TIMESTAMPTZ,
  meta JSONB,
  UNIQUE (chain_id, pool_address)
);

CREATE INDEX IF NOT EXISTS idx_dex_pools_chain ON dex_pools (chain_id);
CREATE INDEX IF NOT EXISTS idx_dex_pools_last_synced ON dex_pools (last_synced_at DESC);

CREATE TABLE IF NOT EXISTS dex_trades (
  chain_id INTEGER NOT NULL,
  pool_address TEXT NOT NULL,
  tx_hash TEXT NOT NULL,
  log_index INTEGER NOT NULL,
  block_number BIGINT NOT NULL,
  time_stamp TIMESTAMPTZ NOT NULL,
  trader_address TEXT,
  side TEXT,
  amount_bzr_raw NUMERIC(78, 0),
  amount_quote_raw NUMERIC(78, 0),
  price_usd NUMERIC,
  value_usd NUMERIC,
  quote_symbol TEXT,
  payload JSONB NOT NULL,
  inserted_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (chain_id, tx_hash, log_index)
);

CREATE INDEX IF NOT EXISTS idx_dex_trades_chain_block ON dex_trades (chain_id, block_number DESC);
CREATE INDEX IF NOT EXISTS idx_dex_trades_pool_block ON dex_trades (pool_address, block_number DESC);
CREATE INDEX IF NOT EXISTS idx_dex_trades_trader ON dex_trades (trader_address);

COMMIT;

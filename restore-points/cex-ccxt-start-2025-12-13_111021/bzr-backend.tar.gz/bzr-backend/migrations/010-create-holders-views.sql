-- Materialized view for fast aggregated "All Chains" and top holders
CREATE MATERIALIZED VIEW IF NOT EXISTS holders_snapshot_top_all AS
SELECT address, chain_id, balance, last_seen
FROM holders_snapshot
ORDER BY balance DESC
LIMIT 2000;

CREATE INDEX IF NOT EXISTS holders_snapshot_top_all_balance_idx
  ON holders_snapshot_top_all (balance DESC);

-- Helper to refresh the materialized view
CREATE OR REPLACE FUNCTION refresh_holders_snapshot_top_all()
RETURNS void AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY holders_snapshot_top_all;
END;
$$ LANGUAGE plpgsql;

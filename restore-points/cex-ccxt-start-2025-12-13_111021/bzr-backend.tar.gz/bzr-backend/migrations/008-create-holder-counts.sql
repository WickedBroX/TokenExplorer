-- Create table to store per-chain holder totals (for pagination/backup)
CREATE TABLE IF NOT EXISTS holder_counts (
  chain_id INTEGER PRIMARY KEY,
  holder_count BIGINT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source TEXT
);

COMMENT ON TABLE holder_counts IS 'Stores latest known holder counts per chain to provide pagination totals and resiliency when upstream APIs fail.';
COMMENT ON COLUMN holder_counts.source IS 'Origin of the count (e.g., etherscan tokenholderlist crawl, manual backfill).';
